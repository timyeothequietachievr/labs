const NOTION_VERSION = "2022-06-28";
const RESOURCES_DATABASE_ID = "27041716-da28-82a4-ad01-815af2387084";
const RESOURCES_DATA_SOURCE_ID = "75141716-da28-83b8-b7cd-873498632913";

chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "tqa-ann-toggle" }, () => {
    void chrome.runtime.lastError;
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type === "tqa-ann-toggle") return;
  if (message.type === "tqa-ann-export-file") {
    exportFile(message).then(sendResponse);
    return true;
  }
  if (message.type === "tqa-ann-export-notion") {
    exportNotion(message).then(sendResponse);
    return true;
  }
  return undefined;
});

async function exportFile(message) {
  try {
    const ext = message.ext === "txt" ? "txt" : message.ext === "html" ? "html" : "md";
    const mime = ext === "txt" ? "text/plain" : ext === "html" ? "text/html" : "text/markdown";
    const filename = String(message.filename || `annotations.${ext}`).replace(/[^\w.\-]+/g, "-");
    const url = `data:${mime};charset=utf-8,${encodeURIComponent(message.text || "")}`;
    const downloadId = await chrome.downloads.download({ url, filename, saveAs: true });
    return { ok: true, downloadId };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "Download failed." };
  }
}

async function notionToken() {
  const stored = await chrome.storage.local.get("notionToken");
  if (stored.notionToken) return stored.notionToken;
  const response = await fetch(chrome.runtime.getURL("notion.local.json"));
  if (!response.ok) return "";
  const data = await response.json();
  return typeof data.token === "string" ? data.token : "";
}

function richText(content) {
  return [{ type: "text", text: { content: String(content || "").slice(0, 2000) } }];
}

function markdownToBlocks(markdown) {
  const blocks = [];
  String(markdown || "").split("\n").forEach((raw) => {
    const line = raw.replace(/\r$/, "");
    if (!line.trim()) return;
    if (line.startsWith("## ")) {
      blocks.push({ object: "block", type: "heading_2", heading_2: { rich_text: richText(line.slice(3)) } });
      return;
    }
    if (line.startsWith("# ")) {
      blocks.push({ object: "block", type: "heading_1", heading_1: { rich_text: richText(line.slice(2)) } });
      return;
    }
    if (line.startsWith("> ")) {
      blocks.push({ object: "block", type: "quote", quote: { rich_text: richText(line.slice(2)) } });
      return;
    }
    if (line.startsWith("- ")) {
      blocks.push({
        object: "block",
        type: "bulleted_list_item",
        bulleted_list_item: { rich_text: richText(line.slice(2)) }
      });
      return;
    }
    blocks.push({ object: "block", type: "paragraph", paragraph: { rich_text: richText(line) } });
  });
  return blocks;
}

async function notionFetch(token, path, body) {
  const response = await fetch(`https://api.notion.com/v1${path}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Notion-Version": NOTION_VERSION,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  return { ok: response.ok, status: response.status, data };
}

async function exportNotion(message) {
  try {
    const token = await notionToken();
    if (!token) {
      return { ok: false, error: "No Notion token found. Add notion.local.json in the extension folder." };
    }
    const today = new Date().toISOString().slice(0, 10);
    const blocks = markdownToBlocks(message.markdown);
    const properties = {
      "Resource name": { title: richText(message.title || "Page annotations") },
      Body: { rich_text: richText(message.summary || "") },
      URL: { url: message.url || null },
      "Date added": { date: { start: today } },
      "Media type": { select: { name: "Text" } },
      "Input/Output": { select: { name: "Input" } }
    };
    const payload = {
      parent: { database_id: RESOURCES_DATABASE_ID },
      icon: { type: "emoji", emoji: "📚" },
      properties,
      children: blocks.slice(0, 90)
    };
    let created = await notionFetch(token, "/pages", payload);
    if (!created.ok && (created.status === 400 || created.status === 404)) {
      payload.parent = { data_source_id: RESOURCES_DATA_SOURCE_ID };
      created = await notionFetch(token, "/pages", payload);
    }
    if (!created.ok) {
      const code = created.data?.code || "";
      if (code === "object_not_found") {
        return {
          ok: false,
          error: "Share the Resources database with your Notion integration, then try again."
        };
      }
      return { ok: false, error: created.data?.message || `Notion API ${created.status}` };
    }
    const pageId = created.data.id;
    for (let index = 90; index < blocks.length; index += 90) {
      const appended = await notionFetch(token, `/blocks/${pageId}/children`, {
        children: blocks.slice(index, index + 90)
      });
      if (!appended.ok) {
        return { ok: false, error: appended.data?.message || "Notion saved the page but not every annotation." };
      }
    }
    return { ok: true, url: created.data.url };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "Notion export failed." };
  }
}
