(function () {
  var dataEl = document.getElementById("tqa-ann-data");
  var cssEl = document.getElementById("tqa-share-ui-css");
  if (!dataEl || !document.body) return;

  var raw = JSON.parse(dataEl.textContent || "[]");
  var notes = Array.isArray(raw) ? raw : raw.notes || [];
  var shareId = Array.isArray(raw) ? "" : String(raw.shareId || "");
  var apiBase = Array.isArray(raw) ? "" : String(raw.apiBase || "");
  var apiKey = Array.isArray(raw) ? "" : String(raw.apiKey || "");
  var sharedLabel = Array.isArray(raw) ? "" : String(raw.sharedLabel || "");
  var byId = {};
  notes.forEach(function (note) {
    byId[note.id] = note;
  });

  var filters = { sentiment: "all", color: "all", comment: "all" };
  var readAt = {};
  var player = null;
  var reel = { ids: [], index: 0, playingId: null };
  var alpha = 100;
  var frame = null;
  var gesture = null;

  function preview(text, max) {
    var flat = String(text || "").replace(/\s+/g, " ").trim();
    if (flat.length <= max) return flat;
    return flat.slice(0, max - 1) + "…";
  }

  function audioSrc(note) {
    if (!note || !note.audio || !note.audio.data) return "";
    return "data:" + (note.audio.mime || "audio/webm") + ";base64," + note.audio.data;
  }

  function matches(note) {
    if (filters.sentiment === "none" && note.sentiment) return false;
    if (filters.sentiment !== "all" && filters.sentiment !== "none" && note.sentiment !== filters.sentiment) {
      return false;
    }
    if (filters.color !== "all" && note.color !== filters.color) return false;
    var hasComment = Boolean(note.comment && String(note.comment).trim());
    if (filters.comment === "with" && !hasComment) return false;
    if (filters.comment === "without" && hasComment) return false;
    return true;
  }

  function opacityLabel(value) {
    if (value <= 0) return "100% transparent";
    if (value >= 100) return "100% opaque";
    return value + "% opaque";
  }

  function defaultFrame() {
    var width = Math.min(400, Math.max(280, window.innerWidth - 32));
    var height = Math.min(Math.max(240, window.innerHeight - 88), window.innerHeight - 16);
    return { left: 16, top: 72, width: width, height: height };
  }

  function clampFrame(next, edge) {
    var minW = 280;
    var minH = 240;
    var left = next.left;
    var top = next.top;
    var width = next.width;
    var height = next.height;
    if (width < minW) {
      if (edge && edge.indexOf("w") !== -1) left -= minW - width;
      width = minW;
    }
    if (height < minH) {
      if (edge && edge.indexOf("n") !== -1) top -= minH - height;
      height = minH;
    }
    width = Math.min(width, window.innerWidth);
    height = Math.min(height, window.innerHeight);
    left = Math.max(0, Math.min(left, Math.max(0, window.innerWidth - width)));
    top = Math.max(0, Math.min(top, Math.max(0, window.innerHeight - height)));
    return { left: left, top: top, width: width, height: height };
  }

  function marksFor(id) {
    return Array.prototype.filter.call(document.querySelectorAll("span.tqa-ann-mark"), function (mark) {
      return mark.getAttribute("data-ann-id") === id;
    });
  }

  function jumpTo(note) {
    var marks = marksFor(note.id);
    if (!marks.length) return;
    marks[0].scrollIntoView({ behavior: "smooth", block: "center" });
    marks.forEach(function (mark) {
      mark.classList.add("tqa-ann-flash");
    });
    window.setTimeout(function () {
      marks.forEach(function (mark) {
        mark.classList.remove("tqa-ann-flash");
      });
    }, 1200);
  }

  function rpc(name, body) {
    if (!apiBase || !apiKey || !shareId) return Promise.reject(new Error("missing api"));
    return fetch(apiBase + name, {
      method: "POST",
      headers: {
        apikey: apiKey,
        Authorization: "Bearer " + apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    }).then(function (response) {
      return response.json();
    });
  }

  function setNoteRead(id, read) {
    if (!shareId) return;
    rpc("notetaker_set_read", { p_share: shareId, p_local_id: id, p_read: read })
      .then(function () {
        readAt[id] = read ? new Date().toISOString() : null;
        renderList();
      })
      .catch(function () {});
  }

  var host = document.createElement("div");
  host.id = "tqa-share-host";
  Object.entries({
    position: "fixed",
    inset: "0",
    width: "100%",
    height: "100%",
    "z-index": "2147483647",
    "pointer-events": "none",
    border: "0",
    margin: "0",
    padding: "0",
    background: "transparent"
  }).forEach(function (entry) {
    host.style.setProperty(entry[0], entry[1], "important");
  });

  var shadow = host.attachShadow({ mode: "open" });
  var styleEl = document.createElement("style");
  styleEl.textContent = cssEl ? cssEl.textContent : "";
  if (cssEl) cssEl.remove();

  var root = document.createElement("div");
  root.className = "tqa-ann-root";
  root.innerHTML =
    '<header id="tqa-share-bar">' +
    '  <div id="tqa-share-brand">' +
    '    <p id="tqa-share-title">Annotator</p>' +
    (sharedLabel ? '    <p id="tqa-share-stamp"></p>' : "") +
    "  </div>" +
    '  <div id="tqa-share-actions">' +
    '    <a id="tqa-share-source" target="_blank" rel="noreferrer">Open original</a>' +
    '    <button type="button" class="tqa-ann-btn tqa-ann-btn-secondary" data-action="toggle-summary" aria-expanded="true">Summary</button>' +
    "  </div>" +
    "</header>" +
    '<aside class="tqa-ann-summary" role="dialog" aria-label="Annotation summary">' +
    '  <div class="tqa-ann-resize" data-resize="n"></div>' +
    '  <div class="tqa-ann-resize" data-resize="s"></div>' +
    '  <div class="tqa-ann-resize" data-resize="e"></div>' +
    '  <div class="tqa-ann-resize" data-resize="w"></div>' +
    '  <div class="tqa-ann-resize" data-resize="nw"></div>' +
    '  <div class="tqa-ann-resize" data-resize="ne"></div>' +
    '  <div class="tqa-ann-resize" data-resize="sw"></div>' +
    '  <div class="tqa-ann-resize" data-resize="se"></div>' +
    '  <div class="tqa-ann-summary-head">' +
    '    <div class="tqa-ann-summary-title-row">' +
    "      <div>" +
    '        <h2 class="tqa-ann-summary-title">Summary</h2>' +
    '        <p class="tqa-ann-count"></p>' +
    "      </div>" +
    '      <button type="button" class="tqa-ann-btn tqa-ann-btn-secondary" data-action="close-summary">Close</button>' +
    "    </div>" +
    '    <label class="tqa-ann-slider">' +
    '      <span class="tqa-ann-slider-row"><span>Transparency</span><span class="tqa-ann-opacity-label"></span></span>' +
    '      <input id="tqa-ann-opacity" type="range" min="0" max="100" value="100" aria-label="Summary panel opacity">' +
    "    </label>" +
    "  </div>" +
    '  <div class="tqa-ann-summary-body">' +
    '    <div class="tqa-ann-filter">' +
    '      <p class="tqa-ann-eyebrow">Feedback</p>' +
    '      <div class="tqa-ann-segment" role="group" aria-label="Feedback">' +
    '        <button type="button" data-action="filter" data-filter="sentiment" data-value="all" aria-pressed="true">All</button>' +
    '        <button type="button" data-action="filter" data-filter="sentiment" data-value="positive">Positive</button>' +
    '        <button type="button" data-action="filter" data-filter="sentiment" data-value="suggestion">Suggestion</button>' +
    '        <button type="button" data-action="filter" data-filter="sentiment" data-value="neutral">Neutral</button>' +
    '        <button type="button" data-action="filter" data-filter="sentiment" data-value="none">None</button>' +
    "      </div>" +
    "    </div>" +
    '    <div class="tqa-ann-filter">' +
    '      <p class="tqa-ann-eyebrow">Highlight</p>' +
    '      <div class="tqa-ann-segment" role="group" aria-label="Highlight">' +
    '        <button type="button" data-action="filter" data-filter="color" data-value="all" aria-pressed="true">All</button>' +
    '        <button type="button" data-action="filter" data-filter="color" data-value="yellow">Yellow</button>' +
    '        <button type="button" data-action="filter" data-filter="color" data-value="purple">Purple</button>' +
    "      </div>" +
    "    </div>" +
    '    <div class="tqa-ann-filter">' +
    '      <p class="tqa-ann-eyebrow">Comment</p>' +
    '      <div class="tqa-ann-segment" role="group" aria-label="Comment">' +
    '        <button type="button" data-action="filter" data-filter="comment" data-value="all" aria-pressed="true">All</button>' +
    '        <button type="button" data-action="filter" data-filter="comment" data-value="with">With comment</button>' +
    '        <button type="button" data-action="filter" data-filter="comment" data-value="without">Without comment</button>' +
    "      </div>" +
    "    </div>" +
    '    <button type="button" class="tqa-ann-btn tqa-ann-btn-primary tqa-ann-play-all" data-action="play-all">Play All</button>' +
    '    <p class="tqa-ann-empty" hidden></p>' +
    '    <ul class="tqa-ann-list"></ul>' +
    "  </div>" +
    "</aside>" +
    '<aside class="tqa-ann-hover" hidden>' +
    '  <p class="tqa-ann-hover-quote"></p>' +
    '  <span class="tqa-ann-tag" hidden></span>' +
    '  <p class="tqa-ann-hover-comment" hidden></p>' +
    "</aside>" +
    '<menu class="tqa-ann-read-menu" hidden>' +
    '  <button type="button" data-action="toggle-read">Mark as unread</button>' +
    "</menu>";

  shadow.append(styleEl, root);

  var summaryBtn = root.querySelector('[data-action="toggle-summary"]');
  var summary = root.querySelector(".tqa-ann-summary");
  var countEl = root.querySelector(".tqa-ann-count");
  var emptyEl = root.querySelector(".tqa-ann-empty");
  var list = root.querySelector(".tqa-ann-list");
  var playAllBtn = root.querySelector('[data-action="play-all"]');
  var opacityInput = root.querySelector("#tqa-ann-opacity");
  var opacityLabelEl = root.querySelector(".tqa-ann-opacity-label");
  var closeBtn = root.querySelector('[data-action="close-summary"]');
  var hover = root.querySelector(".tqa-ann-hover");
  var hoverQuote = root.querySelector(".tqa-ann-hover-quote");
  var hoverTag = root.querySelector(".tqa-ann-hover .tqa-ann-tag");
  var hoverComment = root.querySelector(".tqa-ann-hover-comment");
  var readMenu = root.querySelector(".tqa-ann-read-menu");
  var readMenuBtn = root.querySelector(".tqa-ann-read-menu button");
  var stamp = root.querySelector("#tqa-share-stamp");
  var source = root.querySelector("#tqa-share-source");
  var base = document.querySelector("base");
  source.href = base ? base.href : "#";
  if (stamp) stamp.textContent = sharedLabel;

  function applyFrame() {
    frame = clampFrame(frame || defaultFrame(), "");
    summary.style.left = frame.left + "px";
    summary.style.top = frame.top + "px";
    summary.style.width = frame.width + "px";
    summary.style.height = frame.height + "px";
  }

  function applyOpacity() {
    summary.style.setProperty("--tqa-alpha", String(alpha / 100));
    opacityInput.value = String(alpha);
    opacityLabelEl.textContent = opacityLabel(alpha);
  }

  function stopAudio() {
    if (player) {
      player.pause();
      player = null;
    }
    reel.playingId = null;
    reel.ids = [];
    list.querySelectorAll(".tqa-ann-row.is-playing").forEach(function (row) {
      row.classList.remove("is-playing");
    });
    list.querySelectorAll(".tqa-ann-row-play").forEach(function (btn) {
      btn.textContent = "Play";
    });
    playAllBtn.textContent = "Play All";
  }

  function playSrc(src, onEnded) {
    if (player) {
      player.pause();
      player = null;
    }
    if (!src) return;
    player = new Audio(src);
    player.addEventListener("ended", function () {
      player = null;
      if (onEnded) onEnded();
      else stopAudio();
    });
    player.play().catch(function () {
      stopAudio();
    });
  }

  function setPlaying(id) {
    reel.playingId = id || null;
    list.querySelectorAll(".tqa-ann-row.is-playing").forEach(function (row) {
      row.classList.remove("is-playing");
    });
    list.querySelectorAll(".tqa-ann-row-play").forEach(function (btn) {
      btn.textContent = "Play";
    });
    if (!id) return;
    var btn = list.querySelector('.tqa-ann-row-play[data-id="' + id + '"]');
    var row = btn && btn.closest(".tqa-ann-row");
    if (row) row.classList.add("is-playing");
    if (btn) btn.textContent = "Stop";
  }

  function playNote(note) {
    if (!audioSrc(note)) return;
    if (reel.playingId === note.id && player && !player.paused) {
      stopAudio();
      return;
    }
    reel.ids = [];
    setPlaying(note.id);
    playSrc(audioSrc(note), function () {
      setPlaying(null);
      playAllBtn.textContent = "Play All";
    });
  }

  function playAll() {
    var withAudio = notes.filter(function (note) {
      return matches(note) && audioSrc(note);
    });
    if (!withAudio.length) return;
    if (player && reel.ids.length) {
      stopAudio();
      return;
    }
    reel.ids = withAudio.map(function (note) {
      return note.id;
    });
    reel.index = 0;
    playAllBtn.textContent = "Pause";
    function next() {
      if (reel.index >= reel.ids.length) {
        stopAudio();
        return;
      }
      var note = byId[reel.ids[reel.index]];
      reel.index += 1;
      setPlaying(note.id);
      playSrc(audioSrc(note), next);
      playAllBtn.textContent = "Pause";
    }
    next();
  }

  function renderFilters() {
    root.querySelectorAll("[data-filter]").forEach(function (button) {
      button.setAttribute("aria-pressed", String(filters[button.dataset.filter] === button.dataset.value));
    });
  }

  function renderList() {
    renderFilters();
    countEl.textContent = notes.length + " on this page";
    var rows = notes.filter(matches);
    list.replaceChildren();
    emptyEl.hidden = rows.length !== 0;
    emptyEl.textContent = notes.length
      ? "No annotations match these filters."
      : "No annotations on this page yet.";
    rows.forEach(function (note) {
      var item = document.createElement("li");
      item.className = "tqa-ann-row";
      if (shareId) item.classList.add(readAt[note.id] ? "is-read" : "is-unread");
      if (reel.playingId === note.id) item.classList.add("is-playing");

      var jump = document.createElement("button");
      jump.type = "button";
      jump.className = "tqa-ann-jump";
      jump.dataset.action = "jump";
      jump.dataset.id = note.id;

      var quote = document.createElement("p");
      quote.className = "tqa-ann-quote";
      quote.textContent = preview(note.quote, 220);
      jump.append(quote);

      var meta = document.createElement("div");
      meta.className = "tqa-ann-meta";
      if (note.sentiment) {
        var tag = document.createElement("span");
        tag.className = "tqa-ann-tag";
        tag.setAttribute("data-sentiment", note.sentiment);
        tag.textContent = note.sentimentLabel || "";
        meta.append(tag);
      } else {
        var pill = document.createElement("span");
        pill.className = "tqa-ann-highlight-pill";
        pill.setAttribute("data-color", note.color === "purple" ? "purple" : "yellow");
        pill.textContent = "Highlighted";
        meta.append(pill);
      }
      jump.append(meta);

      if (note.comment) {
        var comment = document.createElement("p");
        comment.className = "tqa-ann-comment-preview";
        comment.textContent = preview(note.comment, 160);
        jump.append(comment);
      }

      jump.addEventListener("click", function (event) {
        var paragraph = event.target.closest
          ? event.target.closest(".tqa-ann-quote, .tqa-ann-comment-preview")
          : null;
        if (
          paragraph &&
          (paragraph.classList.contains("is-expanded") || paragraph.scrollHeight > paragraph.clientHeight + 1)
        ) {
          var expanded = paragraph.classList.toggle("is-expanded");
          var full = paragraph.classList.contains("tqa-ann-comment-preview") ? note.comment : note.quote;
          paragraph.textContent = expanded
            ? full
            : preview(full, paragraph.classList.contains("tqa-ann-comment-preview") ? 160 : 220);
          return;
        }
        jumpTo(note);
      });

      if (shareId) {
        item.addEventListener("contextmenu", function (event) {
          event.preventDefault();
          readMenu.hidden = false;
          readMenu.style.left = event.clientX + "px";
          readMenu.style.top = event.clientY + "px";
          readMenu.dataset.id = note.id;
          readMenuBtn.textContent = readAt[note.id] ? "Mark as unread" : "Mark as read";
        });
      }

      item.append(jump);
      if (audioSrc(note)) {
        var play = document.createElement("button");
        play.type = "button";
        play.className = "tqa-ann-btn tqa-ann-btn-secondary tqa-ann-row-play";
        play.dataset.action = "play-one";
        play.dataset.id = note.id;
        play.textContent = reel.playingId === note.id ? "Stop" : "Play";
        play.addEventListener("click", function (event) {
          event.stopPropagation();
          playNote(note);
        });
        item.append(play);
      }
      list.append(item);
    });
  }

  function setSummaryOpen(open) {
    summary.hidden = !open;
    summaryBtn.setAttribute("aria-expanded", String(open));
  }

  function beginGesture(type, edge, event) {
    event.preventDefault();
    gesture = {
      type: type,
      edge: edge || "",
      startX: event.clientX,
      startY: event.clientY,
      frame: Object.assign({}, frame || defaultFrame())
    };
  }

  function onGestureMove(event) {
    if (!gesture) return;
    var dx = event.clientX - gesture.startX;
    var dy = event.clientY - gesture.startY;
    var start = gesture.frame;
    var next = {
      left: start.left,
      top: start.top,
      width: start.width,
      height: start.height
    };
    if (gesture.type === "move") {
      next.left = start.left + dx;
      next.top = start.top + dy;
    } else {
      var edge = gesture.edge;
      if (edge.indexOf("e") !== -1) next.width = start.width + dx;
      if (edge.indexOf("s") !== -1) next.height = start.height + dy;
      if (edge.indexOf("w") !== -1) {
        next.width = start.width - dx;
        next.left = start.left + dx;
      }
      if (edge.indexOf("n") !== -1) {
        next.height = start.height - dy;
        next.top = start.top + dy;
      }
    }
    frame = clampFrame(next, gesture.type === "resize" ? gesture.edge : "");
    applyFrame();
  }

  function onGestureEnd() {
    gesture = null;
  }

  frame = defaultFrame();
  applyFrame();
  applyOpacity();
  setSummaryOpen(true);
  renderList();
  document.documentElement.appendChild(host);

  if (shareId && apiBase) {
    rpc("notetaker_state", { p_share: shareId })
      .then(function (state) {
        readAt = {};
        ((state && state.notes) || []).forEach(function (note) {
          readAt[note.local_id] = note.read_at || null;
        });
        renderList();
      })
      .catch(function () {});
  }

  summaryBtn.addEventListener("click", function () {
    setSummaryOpen(summary.hidden);
  });
  closeBtn.addEventListener("click", function () {
    setSummaryOpen(false);
  });
  playAllBtn.addEventListener("click", playAll);
  opacityInput.addEventListener("input", function () {
    alpha = Number(opacityInput.value) || 0;
    applyOpacity();
  });
  root.addEventListener("click", function (event) {
    var button = event.target.closest ? event.target.closest("[data-action='filter']") : null;
    if (!button) return;
    filters[button.dataset.filter] = button.dataset.value;
    renderList();
  });
  readMenuBtn.addEventListener("click", function () {
    var id = readMenu.dataset.id;
    readMenu.hidden = true;
    if (!id) return;
    setNoteRead(id, !readAt[id]);
  });
  root.addEventListener("mousedown", function (event) {
    if (event.button !== 0) return;
    if (!readMenu.hidden && !readMenu.contains(event.target)) readMenu.hidden = true;
  });
  document.addEventListener("mousedown", function (event) {
    if (!readMenu.hidden && event.target !== host) readMenu.hidden = true;
  });

  root.querySelector(".tqa-ann-summary-title-row").addEventListener("mousedown", function (event) {
    if (event.button !== 0) return;
    if (event.target.closest && event.target.closest("button, a, input")) return;
    beginGesture("move", "", event);
  });
  root.querySelectorAll("[data-resize]").forEach(function (handle) {
    handle.addEventListener("mousedown", function (event) {
      if (event.button !== 0) return;
      event.stopPropagation();
      beginGesture("resize", handle.getAttribute("data-resize"), event);
    });
  });
  window.addEventListener("mousemove", onGestureMove);
  window.addEventListener("mouseup", onGestureEnd);
  window.addEventListener("resize", function () {
    applyFrame();
  });

  var hoverTimer = 0;
  function hideHover() {
    hover.hidden = true;
  }
  function showHover(note) {
    if (!note) return hideHover();
    hoverQuote.textContent = note.quote || "";
    hoverTag.hidden = !note.sentiment;
    hoverTag.setAttribute("data-sentiment", note.sentiment || "");
    hoverTag.textContent = note.sentimentLabel || "";
    hoverComment.hidden = !note.comment;
    hoverComment.textContent = note.comment || "";
    hover.hidden = false;
    var tops = marksFor(note.id).map(function (item) {
      return item.getBoundingClientRect().top;
    });
    var top = tops.length ? Math.min.apply(null, tops) : 72;
    if (top < 8) top = 8;
    if (top > window.innerHeight - 56) top = window.innerHeight - 56;
    hover.style.top = top + "px";
    hover.style.maxHeight = window.innerHeight - top - 8 + "px";
  }

  document.addEventListener("mouseover", function (event) {
    var mark = event.target && event.target.closest ? event.target.closest("span.tqa-ann-mark") : null;
    if (!mark) return;
    var note = byId[mark.getAttribute("data-ann-id")];
    if (!note) return;
    window.clearTimeout(hoverTimer);
    showHover(note);
  });
  document.addEventListener("mouseout", function (event) {
    var mark = event.target && event.target.closest ? event.target.closest("span.tqa-ann-mark") : null;
    if (!mark) return;
    hoverTimer = window.setTimeout(hideHover, 80);
  });
  hover.addEventListener("mouseenter", function () {
    window.clearTimeout(hoverTimer);
  });
  hover.addEventListener("mouseleave", function () {
    hoverTimer = window.setTimeout(hideHover, 80);
  });
})();
