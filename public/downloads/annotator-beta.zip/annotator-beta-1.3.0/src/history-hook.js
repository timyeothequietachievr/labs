(() => {
  "use strict";
  if (window.__tqaAnnHistoryHook) return;
  window.__tqaAnnHistoryHook = true;

  const notify = () => {
    try {
      window.postMessage({ type: "tqa-ann-url", href: String(location.href || "") }, "*");
    } catch (error) {
      /* ignore */
    }
  };

  ["pushState", "replaceState"].forEach((name) => {
    const original = history[name];
    if (typeof original !== "function" || original.__tqaAnn) return;
    const wrapped = function wrappedHistory(...args) {
      const result = original.apply(this, args);
      notify();
      return result;
    };
    wrapped.__tqaAnn = true;
    history[name] = wrapped;
  });

  window.addEventListener("popstate", notify);
  window.addEventListener("hashchange", notify);
})();
