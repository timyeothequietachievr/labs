(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.TqaAnchor = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const CONTEXT = 48;

  function pageKeyFromHref(href) {
    try {
      const url = new URL(href);
      return url.origin + url.pathname + url.search;
    } catch (error) {
      return String(href || "").split("#")[0];
    }
  }

  function rangesOverlap(a, b) {
    return a.start < b.end && b.start < a.end;
  }

  function scoreHit(text, ann, at) {
    const quote = ann.quote;
    const prefix = ann.prefix || "";
    const suffix = ann.suffix || "";
    const before = text.slice(Math.max(0, at - prefix.length), at);
    const after = text.slice(at + quote.length, at + quote.length + suffix.length);
    let score = 0;
    if (prefix && before.endsWith(prefix)) score += 10;
    else if (prefix.length > 12 && before.endsWith(prefix.slice(-12))) score += 4;
    if (suffix && after.startsWith(suffix)) score += 10;
    else if (suffix.length > 12 && after.startsWith(suffix.slice(0, 12))) score += 4;
    if (Number.isInteger(ann.hint)) score -= Math.min(Math.abs(at - ann.hint), 1000) / 1000;
    return score;
  }

  function bestHit(text, ann, used) {
    const quote = ann.quote || "";
    if (!quote) return null;
    let from = 0;
    let best = null;
    let bestScore = -1;
    while (from < text.length) {
      const at = text.indexOf(quote, from);
      if (at < 0) break;
      const loc = { start: at, end: at + quote.length };
      from = at + 1;
      if (used.some((range) => rangesOverlap(range, loc))) continue;
      const score = scoreHit(text, ann, at);
      if (!best || score > bestScore || (score === bestScore && at < best.start)) {
        best = loc;
        bestScore = score;
      }
    }
    return best;
  }

  function assignLocations(text, annotations) {
    const used = [];
    const out = {};
    const ordered = annotations.slice().sort((a, b) => {
      const lengthDelta = (b.quote || "").length - (a.quote || "").length;
      if (lengthDelta) return lengthDelta;
      return (a.createdAt || 0) - (b.createdAt || 0);
    });
    ordered.forEach((ann) => {
      const loc = bestHit(text || "", ann, used);
      out[ann.id] = loc;
      if (loc) used.push(loc);
    });
    return out;
  }

  return { CONTEXT, pageKeyFromHref, assignLocations };
});
