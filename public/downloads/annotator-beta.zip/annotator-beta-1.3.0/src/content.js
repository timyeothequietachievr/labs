(() => {
  "use strict";

  if (window.__tqaAnnBooted || window.top !== window) return;
  window.__tqaAnnBooted = true;

  function extensionAlive() {
    try {
      return Boolean(chrome.runtime?.id);
    } catch (error) {
      return false;
    }
  }

  function isContextError(error) {
    const message = error instanceof Error ? error.message : String(error || "");
    return /extension context invalidated|context invalidated/i.test(message);
  }

  const STORE_KEY = "tqaAnnotatorV1";
  const SESSION_KEY = "tqaAnnotatorSession";
  const SHARES_KEY = "tqaAnnotatorShares";
  const AUDIO_KEY = "tqaAnnAudioV1";
  const SUPABASE_URL = "https://towjcfllxlagukdwfpax.supabase.co";
  const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRvd2pjZmxseGxhZ3VrZHdmcGF4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU1MzI4ODgsImV4cCI6MjA4MTEwODg4OH0.YuW6gkqncL0eZHtQyV1oy-ckCRsLgGeTGuYSRy76TY0";
  const PAINT = {
    yellow: "rgba(229, 164, 2, 0.48)",
    purple: "rgba(107, 76, 154, 0.34)",
    positive: "rgba(47, 125, 74, 0.42)",
    suggestion: "rgba(196, 53, 43, 0.4)",
    neutral: "rgba(43, 43, 82, 0.32)"
  };
  const SENTIMENTS = ["positive", "suggestion", "neutral"];
  const SENTIMENT_LABELS = { positive: "Positive", suggestion: "Suggestion", neutral: "Neutral" };
  const SKIP = "script, style, noscript, textarea, input, select, option, svg, canvas, iframe, head";

  const state = {
    barOpen: false,
    annotationsVisible: true,
    summaryOpacity: 100,
    summaryFrame: null,
    summaryOpen: false,
    lastColor: "yellow",
    page: "",
    annotations: [],
    locations: {},
    index: null,
    editor: null,
    hoverId: null,
    filters: { sentiment: "all", color: "all", comment: "all" },
    session: null,
    shareId: null,
    readAt: {},
    audioIds: {},
    authMode: "signin",
    resetToken: ""
  };

  let memory = null;
  let queue = Promise.resolve();
  let writesInFlight = 0;
  let cssText = null;
  let uiCssReady = false;
  let hoverTimer = 0;
  let sharePoll = 0;
  let retired = false;
  let mediaRecorder = null;
  let recordChunks = [];
  let recordStream = null;
  let draftAudio = null;
  let draftAudioUrl = "";
  let draftPlayer = null;
  const reel = { ids: [], index: 0, audio: null, paused: false, playingId: null };
  const ui = {};

  function clampOpacity(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return 100;
    return Math.max(0, Math.min(100, Math.round(number)));
  }

  function normalizeAnn(raw) {
    if (!raw || typeof raw.id !== "string" || typeof raw.quote !== "string" || !raw.quote) return null;
    return {
      id: raw.id,
      quote: raw.quote,
      prefix: typeof raw.prefix === "string" ? raw.prefix : "",
      suffix: typeof raw.suffix === "string" ? raw.suffix : "",
      color: raw.color === "purple" ? "purple" : "yellow",
      sentiment: sentimentOf(raw.sentiment),
      comment: typeof raw.comment === "string" ? raw.comment : "",
      createdAt: Number(raw.createdAt) || Date.now(),
      hasAudio: Boolean(raw.hasAudio)
    };
  }

  function serialize(ann) {
    return {
      id: ann.id,
      quote: ann.quote,
      prefix: ann.prefix || "",
      suffix: ann.suffix || "",
      color: ann.color === "purple" ? "purple" : "yellow",
      sentiment: sentimentOf(ann.sentiment),
      comment: ann.comment || "",
      createdAt: ann.createdAt || Date.now(),
      hasAudio: Boolean(ann.hasAudio)
    };
  }

  async function readStore() {
    const stored = await chrome.storage.local.get(STORE_KEY);
    const data = stored[STORE_KEY] || {};
    return {
      lastColor: data.lastColor === "purple" ? "purple" : "yellow",
      annotationsVisible: data.annotationsVisible !== false,
      summaryOpacity: clampOpacity(data.summaryOpacity),
      summaryFrame: normalizeFrame(data.summaryFrame),
      pages: data.pages && typeof data.pages === "object" ? data.pages : {}
    };
  }

  function normalizeFrame(raw) {
    if (!raw || typeof raw !== "object") return null;
    const frame = {
      left: Number(raw.left),
      top: Number(raw.top),
      width: Number(raw.width),
      height: Number(raw.height)
    };
    if (Object.values(frame).some((value) => !Number.isFinite(value))) return null;
    return frame;
  }

  function annotationsFromMemory(page) {
    const list = memory.pages[page] || [];
    return list.map(normalizeAnn).filter(Boolean);
  }

  const SITE_BACKUP_KEY = "tqaAnnotatorBackupV1";

  function pageOrigin(pageKey) {
    try {
      return new URL(pageKey).origin;
    } catch (error) {
      return "";
    }
  }

  function pagesForOrigin(pages, origin) {
    const copy = {};
    Object.entries(pages || {}).forEach(([key, list]) => {
      if (pageOrigin(key) === origin && Array.isArray(list)) copy[key] = list;
    });
    return copy;
  }

  function readSiteBackup() {
    try {
      const raw = localStorage.getItem(SITE_BACKUP_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      if (!data || typeof data.pages !== "object" || data.pages === null) return null;
      return data;
    } catch (error) {
      return null;
    }
  }

  function mergeAnnotationLists(existing, incoming) {
    const byId = new Map();
    incoming.map(normalizeAnn).filter(Boolean).forEach((ann) => byId.set(ann.id, serialize(ann)));
    existing.map(normalizeAnn).filter(Boolean).forEach((ann) => {
      const previous = byId.get(ann.id);
      const current = serialize(ann);
      if (!previous || (current.comment || "").trim().length >= (previous.comment || "").trim().length) {
        byId.set(ann.id, current);
      }
    });
    return Array.from(byId.values());
  }

  function restoreFromSiteBackup() {
    const backup = readSiteBackup();
    if (!backup) return false;
    const origin = location.origin;
    const hadNotes = Object.keys(pagesForOrigin(memory.pages, origin)).length > 0;
    let changed = false;
    Object.entries(backup.pages).forEach(([key, list]) => {
      if (pageOrigin(key) !== origin || !Array.isArray(list) || !list.length) return;
      const existing = Array.isArray(memory.pages[key]) ? memory.pages[key] : [];
      const merged = mergeAnnotationLists(existing, list);
      const existingSerialized = existing.map(normalizeAnn).filter(Boolean).map(serialize);
      if (JSON.stringify(merged) !== JSON.stringify(existingSerialized)) {
        memory.pages[key] = merged;
        changed = true;
      }
    });
    if (!hadNotes) {
      if (backup.lastColor === "purple" || backup.lastColor === "yellow") memory.lastColor = backup.lastColor;
      if (backup.summaryFrame) memory.summaryFrame = normalizeFrame(backup.summaryFrame);
      if (backup.summaryOpacity != null) memory.summaryOpacity = clampOpacity(backup.summaryOpacity);
    }
    return changed;
  }

  function writeSiteBackup() {
    try {
      const origin = location.origin;
      localStorage.setItem(SITE_BACKUP_KEY, JSON.stringify({
        savedAt: Date.now(),
        lastColor: memory.lastColor,
        summaryOpacity: memory.summaryOpacity,
        summaryFrame: memory.summaryFrame,
        pages: pagesForOrigin(memory.pages, origin)
      }));
    } catch (error) {
      console.error("Annotator could not keep a copy of these notes on the site", error);
    }
  }

  function retire(error) {
    if (retired) return;
    retired = true;
    if (sharePoll) window.clearInterval(sharePoll);
    sharePoll = 0;
    clearTimeout(hoverTimer);
    try {
      unwrapAll();
    } catch (unwrapError) {
      /* page may already be tearing down */
    }
    try {
      ui.host?.remove();
    } catch (hostError) {
      /* ignore */
    }
    window.__tqaAnnBooted = false;
    if (error && !isContextError(error)) console.error("Annotator stopped", error);
  }

  function persist() {
    if (!extensionAlive()) {
      retire();
      return queue;
    }
    const page = state.page;
    const snapshot = state.annotations.map(serialize);
    const lastColor = state.lastColor;
    const annotationsVisible = state.annotationsVisible;
    const summaryOpacity = state.summaryOpacity;
    const summaryFrame = state.summaryFrame ? { ...state.summaryFrame } : null;
    writesInFlight += 1;
    queue = queue.then(async () => {
      try {
        if (!extensionAlive()) {
          retire();
          return;
        }
        if (!memory) memory = await readStore();
        memory.lastColor = lastColor;
        memory.annotationsVisible = annotationsVisible;
        memory.summaryOpacity = summaryOpacity;
        memory.summaryFrame = summaryFrame;
        memory.pages[page] = snapshot;
        await chrome.storage.local.set({ [STORE_KEY]: memory });
        writeSiteBackup();
      } catch (error) {
        if (isContextError(error)) retire(error);
        else console.error("Annotator could not save", error);
      } finally {
        writesInFlight -= 1;
      }
    });
    return queue;
  }

  function sentimentOf(value) {
    const sentiment = value === "negative" ? "suggestion" : value;
    return SENTIMENTS.includes(sentiment) ? sentiment : null;
  }

  function sentimentLabel(value) {
    return SENTIMENT_LABELS[value] || "";
  }

  function preview(text, max) {
    const flat = String(text || "").replace(/\s+/g, " ").trim();
    if (flat.length <= max) return flat;
    return `${flat.slice(0, max - 1)}…`;
  }

  function motion() {
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
  }

  function newId() {
    try {
      return crypto.randomUUID();
    } catch (error) {
      return `ann-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    }
  }

  function shouldSkipNode(node) {
    if (!node) return true;
    const element = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    if (!element || element.closest(SKIP)) return true;
    const editable = element.closest("[contenteditable]");
    if (editable && editable.getAttribute("contenteditable") !== "false") return true;
    if (element.closest("#tqa-ann-host")) return true;
    return false;
  }

  function buildIndex() {
    const records = [];
    const byNode = new Map();
    let text = "";
    if (!document.body) return { text, records, byNode };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || shouldSkipNode(node)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const start = text.length;
      text += node.nodeValue;
      const rec = { node, start, end: text.length };
      records.push(rec);
      byNode.set(node, rec);
    }
    return { text, records, byNode };
  }

  function startOffsetOf(index, node) {
    if (!node) return null;
    if (node.nodeType === Node.TEXT_NODE) {
      const rec = index.byNode.get(node);
      return rec ? rec.start : null;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return null;
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, {
      acceptNode(current) {
        return index.byNode.has(current) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    const first = walker.nextNode();
    if (first) return index.byNode.get(first).start;
    for (const rec of index.records) {
      if (node.compareDocumentPosition(rec.node) & Node.DOCUMENT_POSITION_FOLLOWING) return rec.start;
    }
    return index.text.length;
  }

  function offsetOfPoint(index, container, offset) {
    if (!container) return null;
    if (container.nodeType === Node.TEXT_NODE) {
      const rec = index.byNode.get(container);
      if (!rec) return null;
      const bounded = Math.min(Math.max(offset, 0), container.nodeValue.length);
      return rec.start + bounded;
    }
    if (container.nodeType !== Node.ELEMENT_NODE) return null;
    const child = container.childNodes[offset];
    if (child) return startOffsetOf(index, child);
    if (offset > 0) {
      const previous = container.childNodes[offset - 1];
      const start = startOffsetOf(index, previous);
      if (start == null) return null;
      if (previous.nodeType === Node.TEXT_NODE) {
        const rec = index.byNode.get(previous);
        return rec ? rec.end : start;
      }
      const walker = document.createTreeWalker(previous, NodeFilter.SHOW_TEXT, {
        acceptNode(current) {
          return index.byNode.has(current) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        }
      });
      let last = null;
      let current = walker.nextNode();
      while (current) {
        last = current;
        current = walker.nextNode();
      }
      return last ? index.byNode.get(last).end : start;
    }
    return startOffsetOf(index, container);
  }

  function unwrapAll() {
    document.querySelectorAll("span.tqa-ann-mark").forEach((mark) => {
      const parent = mark.parentNode;
      if (!parent) return;
      while (mark.firstChild) parent.insertBefore(mark.firstChild, mark);
      parent.removeChild(mark);
      parent.normalize();
    });
  }

  function paintOf(color) {
    return PAINT[color] || PAINT.yellow;
  }

  function displayColor(ann) {
    const sentiment = sentimentOf(ann?.sentiment);
    if (sentiment) return sentiment;
    return ann?.color === "purple" ? "purple" : "yellow";
  }

  function wrapTextNode(node, start, end, id, color) {
    const text = node.nodeValue || "";
    const safeStart = Math.max(0, Math.min(start, text.length));
    const safeEnd = Math.max(safeStart, Math.min(end, text.length));
    if (safeEnd <= safeStart || !node.parentNode) return node;
    const before = text.slice(0, safeStart);
    const mid = text.slice(safeStart, safeEnd);
    const after = text.slice(safeEnd);
    const mark = document.createElement("span");
    mark.className = "tqa-ann-mark";
    mark.dataset.annId = id;
    mark.dataset.color = PAINT[color] ? color : "yellow";
    mark.style.backgroundColor = paintOf(mark.dataset.color);
    mark.textContent = mid;
    const fragment = document.createDocumentFragment();
    let beforeNode = null;
    if (before) {
      beforeNode = document.createTextNode(before);
      fragment.appendChild(beforeNode);
    }
    fragment.appendChild(mark);
    if (after) fragment.appendChild(document.createTextNode(after));
    node.parentNode.replaceChild(fragment, node);
    return beforeNode;
  }

  function applySlices(slices) {
    const groups = new Map();
    slices.forEach((slice) => {
      if (!groups.has(slice.node)) groups.set(slice.node, []);
      groups.get(slice.node).push(slice);
    });
    groups.forEach((group, node) => {
      group.sort((a, b) => b.localStart - a.localStart);
      let current = node;
      group.forEach((slice) => {
        if (!current) return;
        const before = wrapTextNode(current, slice.localStart, slice.localEnd, slice.id, slice.color);
        current = before;
      });
    });
  }

  function rememberLocations(index, locations) {
    state.locations = locations;
    state.annotations.forEach((ann) => {
      const loc = locations[ann.id];
      ann.found = Boolean(loc);
      ann.pos = loc ? loc.start : Number.POSITIVE_INFINITY;
    });
    state.index = index;
  }

  function refreshLocations() {
    const index = buildIndex();
    rememberLocations(index, TqaAnchor.assignLocations(index.text, state.annotations));
  }

  function paintAll() {
    unwrapAll();
    const index = buildIndex();
    const locations = TqaAnchor.assignLocations(index.text, state.annotations);
    rememberLocations(index, locations);
    const slices = [];
    state.annotations.forEach((ann) => {
      const loc = locations[ann.id];
      if (!loc) return;
      index.records.forEach((rec) => {
        const start = Math.max(rec.start, loc.start);
        const end = Math.min(rec.end, loc.end);
        if (start < end) {
          slices.push({
            node: rec.node,
            localStart: start - rec.start,
            localEnd: end - rec.start,
            id: ann.id,
            color: displayColor(ann)
          });
        }
      });
    });
    applySlices(slices);
    state.index = null;
  }

  function syncMarks() {
    if (state.barOpen && state.annotationsVisible) paintAll();
    else {
      unwrapAll();
      refreshLocations();
    }
    renderList();
  }

  function recolor(id, color) {
    document.querySelectorAll(`span.tqa-ann-mark[data-ann-id="${CSS.escape(id)}"]`).forEach((mark) => {
      mark.dataset.color = color;
      mark.style.backgroundColor = paintOf(color);
    });
  }

  function matches(ann) {
    const filters = state.filters;
    if (filters.sentiment === "none" && ann.sentiment) return false;
    if (filters.sentiment !== "all" && filters.sentiment !== "none" && ann.sentiment !== filters.sentiment) return false;
    if (filters.color !== "all" && ann.color !== filters.color) return false;
    const hasComment = Boolean(ann.comment && ann.comment.trim());
    if (filters.comment === "with" && !hasComment) return false;
    if (filters.comment === "without" && hasComment) return false;
    return true;
  }

  function opacityLabel(value) {
    if (value <= 0) return "100% transparent";
    if (value >= 100) return "100% opaque";
    return `${value}% opaque`;
  }

  function defaultFrame() {
    const width = Math.min(400, Math.max(280, window.innerWidth - 32));
    const height = Math.min(Math.max(240, window.innerHeight - 88), window.innerHeight - 16);
    return { left: 16, top: 72, width, height };
  }

  function clampFrame(frame, edge) {
    const minW = 280;
    const minH = 240;
    let { left, top, width, height } = frame;
    if (width < minW) {
      if (edge && edge.includes("w")) left -= minW - width;
      width = minW;
    }
    if (height < minH) {
      if (edge && edge.includes("n")) top -= minH - height;
      height = minH;
    }
    width = Math.min(width, window.innerWidth);
    height = Math.min(height, window.innerHeight);
    left = Math.max(0, Math.min(left, Math.max(0, window.innerWidth - width)));
    top = Math.max(0, Math.min(top, Math.max(0, window.innerHeight - height)));
    return { left, top, width, height };
  }

  function applyFrame() {
    const frame = clampFrame(state.summaryFrame || defaultFrame(), "");
    ui.summary.style.left = `${frame.left}px`;
    ui.summary.style.top = `${frame.top}px`;
    ui.summary.style.width = `${frame.width}px`;
    ui.summary.style.height = `${frame.height}px`;
  }

  function applyOpacity() {
    const value = clampOpacity(state.summaryOpacity);
    ui.summary.style.setProperty("--tqa-alpha", String(value / 100));
    ui.opacity.value = String(value);
    ui.opacityLabel.textContent = opacityLabel(value);
  }

  function renderVisibility() {
    ui.bar.hidden = !state.barOpen;
    const summaryOpen = state.summaryOpen && state.barOpen;
    ui.summary.hidden = !summaryOpen;
    ui.summaryButton.setAttribute("aria-expanded", String(summaryOpen));
    ui.toggle.setAttribute("aria-checked", String(state.annotationsVisible));
    if (!state.barOpen || !state.annotationsVisible || state.editor) hideHover();
  }

  function renderFilters() {
    ui.root.querySelectorAll("[data-filter]").forEach((button) => {
      button.setAttribute("aria-pressed", String(state.filters[button.dataset.filter] === button.dataset.value));
    });
  }

  function renderList() {
    if (!ui.list) return;
    renderFilters();
    ui.count.textContent = `${state.annotations.length} on this page`;
    const rows = state.annotations.filter(matches).sort((a, b) => (a.pos ?? Infinity) - (b.pos ?? Infinity) || a.createdAt - b.createdAt);
    ui.list.replaceChildren();
    ui.empty.hidden = rows.length !== 0;
    if (!rows.length) {
      ui.empty.textContent = state.annotations.length
        ? "No annotations match these filters."
        : "No annotations on this page yet.";
    }
    rows.forEach((ann) => ui.list.append(renderRow(ann)));
    if (reel.playingId && reel.audio && !reel.audio.paused) setPlayingRow(reel.playingId);
  }

  function flatText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function isLineClamped(paragraph) {
    if (paragraph.scrollHeight > paragraph.clientHeight + 1) return true;
    const clone = paragraph.cloneNode(true);
    clone.classList.add("is-expanded");
    clone.style.visibility = "hidden";
    clone.style.position = "absolute";
    clone.style.pointerEvents = "none";
    clone.style.width = `${paragraph.getBoundingClientRect().width}px`;
    paragraph.insertAdjacentElement("afterend", clone);
    const taller = clone.offsetHeight > paragraph.offsetHeight + 1;
    clone.remove();
    return taller;
  }

  function canRevealParagraph(paragraph, id) {
    if (paragraph.classList.contains("is-expanded")) return true;
    if (isLineClamped(paragraph)) return true;
    const ann = state.annotations.find((item) => item.id === id);
    if (!ann) return false;
    const full = paragraph.classList.contains("tqa-ann-comment-preview") ? ann.comment : ann.quote;
    return paragraph.textContent !== flatText(full);
  }

  function toggleParagraph(paragraph, id) {
    const ann = state.annotations.find((item) => item.id === id);
    if (!ann) return;
    const comment = paragraph.classList.contains("tqa-ann-comment-preview");
    const full = comment ? ann.comment : ann.quote;
    const expanded = paragraph.classList.toggle("is-expanded");
    paragraph.textContent = expanded ? full : preview(full, comment ? 160 : 220);
  }

  function renderRow(ann) {
    const item = document.createElement("li");
    item.className = "tqa-ann-row";
    if (state.shareId) item.classList.add(state.readAt[ann.id] ? "is-read" : "is-unread");
    item.addEventListener("contextmenu", (event) => showReadMenu(event, ann));

    const jump = document.createElement("button");
    jump.type = "button";
    jump.className = "tqa-ann-jump";
    jump.dataset.action = "jump";
    jump.dataset.id = ann.id;
    jump.setAttribute("aria-label", `Go to highlight: ${preview(ann.quote, 80)}`);

    const quote = document.createElement("p");
    quote.className = "tqa-ann-quote";
    quote.textContent = preview(ann.quote, 220);
    jump.append(quote);

    const meta = document.createElement("div");
    meta.className = "tqa-ann-meta";
    if (ann.sentiment) {
      const tag = document.createElement("span");
      tag.className = "tqa-ann-tag";
      tag.dataset.sentiment = ann.sentiment;
      tag.textContent = sentimentLabel(ann.sentiment);
      meta.append(tag);
    } else {
      const pill = document.createElement("span");
      pill.className = "tqa-ann-highlight-pill";
      pill.dataset.color = ann.color === "purple" ? "purple" : "yellow";
      pill.textContent = "Highlighted";
      meta.append(pill);
    }
    if (!ann.found) {
      const missing = document.createElement("span");
      missing.className = "tqa-ann-missing";
      missing.textContent = "Not on this page";
      meta.append(missing);
    }
    jump.append(meta);
    if (ann.comment && ann.comment.trim()) {
      const comment = document.createElement("p");
      comment.className = "tqa-ann-comment-preview";
      comment.textContent = preview(ann.comment, 160);
      jump.append(comment);
    }

    item.append(jump);
    if (ann.hasAudio) {
      const play = document.createElement("button");
      play.type = "button";
      play.className = "tqa-ann-btn tqa-ann-btn-secondary tqa-ann-row-play";
      play.dataset.action = "play-one";
      play.dataset.id = ann.id;
      play.textContent = "Play";
      item.append(play);
    }
    return item;
  }

  function updateEditorControls() {
    const ann = currentAnnotation();
    if (!ann) return;
    ui.root.querySelectorAll(".tqa-ann-swatch").forEach((button) => {
      button.setAttribute("aria-pressed", String(button.dataset.color === ann.color));
    });
    ui.root.querySelectorAll(".tqa-ann-sentiment").forEach((button) => {
      button.setAttribute("aria-pressed", String(button.dataset.sentiment === ann.sentiment));
    });
  }

  function currentAnnotation() {
    if (!state.editor) return null;
    return state.annotations.find((ann) => ann.id === state.editor.id) || null;
  }

  function placeEditor(id) {
    const mark = document.querySelector(`span.tqa-ann-mark[data-ann-id="${CSS.escape(id)}"]`);
    const markRect = mark ? mark.getBoundingClientRect() : null;
    const rect = markRect && (markRect.width || markRect.height) ? markRect : state.editor?.rect;
    const width = ui.editor.offsetWidth || 320;
    const height = ui.editor.offsetHeight || 280;
    const margin = 8;
    let top = (rect ? rect.bottom : 72) + margin;
    let left = rect ? rect.left : 16;
    if (top + height > window.innerHeight - margin) top = Math.max(margin, (rect ? rect.top : 72) - height - margin);
    if (left + width > window.innerWidth - margin) left = window.innerWidth - width - margin;
    ui.editor.style.top = `${Math.max(margin, top)}px`;
    ui.editor.style.left = `${Math.max(margin, left)}px`;
  }

  function closeEditor() {
    state.editor = null;
    ui.editor.hidden = true;
    ui.comment.value = "";
  }

  function hideHover() {
    clearTimeout(hoverTimer);
    state.hoverId = null;
    ui.hover.hidden = true;
  }

  function placeHover() {
    const marks = state.hoverId
      ? [...document.querySelectorAll(`span.tqa-ann-mark[data-ann-id="${CSS.escape(state.hoverId)}"]`)]
      : [];
    const margin = 8;
    let top = marks.length ? Math.min(...marks.map((mark) => mark.getBoundingClientRect().top)) : 72;
    top = Math.max(margin, Math.min(top, window.innerHeight - margin - 48));
    ui.hover.style.top = `${top}px`;
    ui.hover.style.maxHeight = `${window.innerHeight - top - margin}px`;
  }

  function showHover(id) {
    if (!state.barOpen || !state.annotationsVisible || state.editor) return;
    const ann = state.annotations.find((item) => item.id === id);
    if (!ann) return hideHover();
    state.hoverId = id;
    ui.hoverQuote.textContent = ann.quote || "";
    if (ann.sentiment) {
      ui.hoverTag.hidden = false;
      ui.hoverTag.dataset.sentiment = ann.sentiment;
      ui.hoverTag.textContent = sentimentLabel(ann.sentiment);
    } else {
      ui.hoverTag.hidden = true;
    }
    if (ann.comment && ann.comment.trim()) {
      ui.hoverComment.hidden = false;
      ui.hoverComment.textContent = ann.comment;
    } else {
      ui.hoverComment.hidden = true;
    }
    ui.hover.hidden = false;
    placeHover();
  }

  const ICON_PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>';
  const ICON_STOP = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6 6h12v12H6z"/></svg>';
  const ICON_UNDO = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6a6 6 0 0 1-6 6 6 6 0 0 1-6-6H4a8 8 0 0 0 8 8 8 8 0 0 0 8-8c0-4.42-3.58-8-8-8z"/></svg>';
  const ICON_TRASH = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>';

  function clearDraftAudio() {
    stopRecording(false);
    if (draftPlayer) {
      draftPlayer.pause();
      draftPlayer = null;
    }
    if (draftAudioUrl) URL.revokeObjectURL(draftAudioUrl);
    draftAudio = null;
    draftAudioUrl = "";
  }

  function setAudioStatus(message) {
    if (ui.audioStatus) ui.audioStatus.textContent = message || "";
  }

  function setIconButton(button, icon, label) {
    if (!button) return;
    button.innerHTML = icon;
    button.setAttribute("aria-label", label);
    button.title = label;
  }

  function updateAudioControls() {
    const recording = Boolean(mediaRecorder && mediaRecorder.state === "recording");
    const hasDraft = Boolean(draftAudio);
    const removed = Boolean(state.editor?.audioRemoved);
    const hasSaved = Boolean(currentAnnotation()?.hasAudio) && !removed;
    const canPlay = (hasDraft || hasSaved) && !recording;
    const showManage = !recording && (hasDraft || hasSaved);
    ui.recordButton.hidden = showManage;
    ui.recordButton.textContent = recording ? "Stop" : "Record";
    ui.playDraftButton.hidden = !canPlay;
    ui.restartDraftButton.hidden = !showManage;
    ui.deleteAudioButton.hidden = !(showManage && hasSaved && !hasDraft);
    if (canPlay) setIconButton(ui.playDraftButton, draftPlayer ? ICON_STOP : ICON_PLAY, draftPlayer ? "Stop" : "Play");
    if (showManage) setIconButton(ui.restartDraftButton, ICON_UNDO, "Restart");
    if (!ui.deleteAudioButton.hidden) setIconButton(ui.deleteAudioButton, ICON_TRASH, "Delete recording");
    if (recording) setAudioStatus("Recording…");
    else if (removed && !hasDraft) setAudioStatus("Recording removed. Save to confirm.");
    else if (hasDraft) setAudioStatus("Recording ready. Save to keep it.");
    else if (hasSaved) setAudioStatus("Saved recording on this highlight.");
    else setAudioStatus("");
  }

  async function stopRecording(keep) {
    if (recordStream) {
      recordStream.getTracks().forEach((track) => track.stop());
      recordStream = null;
    }
    if (!mediaRecorder) return;
    const recorder = mediaRecorder;
    mediaRecorder = null;
    if (recorder.state === "recording") {
      await new Promise((resolve) => {
        recorder.addEventListener("stop", resolve, { once: true });
        recorder.stop();
      });
    }
    if (!keep) {
      recordChunks = [];
      return;
    }
    const blob = new Blob(recordChunks, { type: recorder.mimeType || "audio/webm" });
    recordChunks = [];
    if (!blob.size) return;
    if (draftAudioUrl) URL.revokeObjectURL(draftAudioUrl);
    draftAudio = blob;
    draftAudioUrl = URL.createObjectURL(blob);
  }

  async function startRecording() {
    clearDraftAudio();
    if (state.editor && currentAnnotation()?.hasAudio) state.editor.audioRemoved = true;
    recordStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    recordChunks = [];
    const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
      ? "audio/webm;codecs=opus"
      : MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : "";
    mediaRecorder = mime ? new MediaRecorder(recordStream, { mimeType: mime }) : new MediaRecorder(recordStream);
    mediaRecorder.addEventListener("dataavailable", (event) => {
      if (event.data && event.data.size) recordChunks.push(event.data);
    });
    mediaRecorder.start();
    updateAudioControls();
  }

  async function toggleRecording() {
    try {
      if (mediaRecorder && mediaRecorder.state === "recording") {
        await stopRecording(true);
        updateAudioControls();
        return;
      }
      await startRecording();
    } catch (error) {
      setAudioStatus("Microphone access is needed to record.");
      updateAudioControls();
    }
  }

  async function playDraftOrSaved() {
    if (draftPlayer) {
      draftPlayer.pause();
      draftPlayer = null;
      updateAudioControls();
      return;
    }
    let url = draftAudioUrl;
    if (!url) {
      const blob = await loadAudioBlob(state.editor?.id);
      if (!blob) return;
      url = URL.createObjectURL(blob);
    }
    draftPlayer = new Audio(url);
    draftPlayer.addEventListener("ended", () => {
      draftPlayer = null;
      updateAudioControls();
    });
    await draftPlayer.play();
    setIconButton(ui.playDraftButton, ICON_STOP, "Stop");
  }

  async function getAudioMap() {
    const stored = await chrome.storage.local.get(AUDIO_KEY);
    return stored[AUDIO_KEY] && typeof stored[AUDIO_KEY] === "object" ? stored[AUDIO_KEY] : {};
  }

  async function saveAudioBlob(id, blob) {
    const map = await getAudioMap();
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let index = 0; index < bytes.length; index += 1) binary += String.fromCharCode(bytes[index]);
    map[id] = { mime: blob.type || "audio/webm", data: btoa(binary) };
    await chrome.storage.local.set({ [AUDIO_KEY]: map });
    state.audioIds[id] = true;
  }

  async function loadAudioBlob(id) {
    const map = await getAudioMap();
    const entry = map[id];
    if (!entry?.data) return null;
    const binary = atob(entry.data);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return new Blob([bytes], { type: entry.mime || "audio/webm" });
  }

  async function deleteAudioBlob(id) {
    const map = await getAudioMap();
    if (!map[id]) return;
    delete map[id];
    await chrome.storage.local.set({ [AUDIO_KEY]: map });
    delete state.audioIds[id];
  }

  async function refreshAudioFlags() {
    const map = await getAudioMap();
    state.audioIds = Object.fromEntries(Object.keys(map).map((id) => [id, true]));
    state.annotations.forEach((ann) => {
      ann.hasAudio = Boolean(map[ann.id]);
    });
  }

  function setPlayingRow(id) {
    reel.playingId = id || null;
    if (!ui.list) return;
    ui.list.querySelectorAll(".tqa-ann-row.is-playing").forEach((row) => row.classList.remove("is-playing"));
    if (!id) return;
    const playButton = ui.list.querySelector(`[data-action="play-one"][data-id="${CSS.escape(id)}"]`);
    const row = playButton?.closest(".tqa-ann-row");
    if (row) row.classList.add("is-playing");
  }

  function stopReel(reset) {
    if (reel.audio) {
      reel.audio.pause();
      if (reset) {
        reel.audio.currentTime = 0;
        reel.paused = false;
        reel.index = 0;
      } else {
        reel.paused = true;
      }
    } else if (reset) {
      reel.paused = false;
      reel.index = 0;
    }
    setPlayingRow(null);
    if (ui.playAllButton) ui.playAllButton.textContent = "Play All";
  }

  async function playReelFrom(index) {
    const ids = reel.ids;
    if (!ids.length) return;
    if (index >= ids.length) {
      reel.audio = null;
      reel.paused = false;
      reel.index = 0;
      setPlayingRow(null);
      if (ui.playAllButton) ui.playAllButton.textContent = "Play All";
      return;
    }
    reel.index = index;
    const id = ids[index];
    jumpTo(id);
    setPlayingRow(id);
    const blob = await loadAudioBlob(id);
    if (!blob) {
      await playReelFrom(index + 1);
      return;
    }
    if (reel.audio) {
      reel.audio.pause();
      URL.revokeObjectURL(reel.audio.src);
    }
    const url = URL.createObjectURL(blob);
    const audio = new Audio(url);
    reel.audio = audio;
    reel.paused = false;
    if (ui.playAllButton) ui.playAllButton.textContent = "Pause";
    audio.addEventListener("ended", () => {
      URL.revokeObjectURL(url);
      void playReelFrom(index + 1);
    });
    await audio.play();
  }

  async function togglePlayAll() {
    if (reel.audio && !reel.audio.paused) {
      reel.audio.pause();
      reel.paused = true;
      setPlayingRow(null);
      if (ui.playAllButton) ui.playAllButton.textContent = "Play All";
      return;
    }
    if (reel.audio && reel.paused) {
      reel.paused = false;
      setPlayingRow(reel.ids[reel.index] || null);
      if (ui.playAllButton) ui.playAllButton.textContent = "Pause";
      await reel.audio.play();
      return;
    }
    reel.ids = sortedAnnotations().filter((ann) => ann.hasAudio).map((ann) => ann.id);
    if (!reel.ids.length) {
      setExportStatus("No recordings on this page.");
      return;
    }
    await playReelFrom(reel.index || 0);
  }

  async function playOne(id) {
    jumpTo(id);
    const blob = await loadAudioBlob(id);
    if (!blob) return;
    if (reel.audio) {
      reel.audio.pause();
      reel.paused = false;
    }
    const url = URL.createObjectURL(blob);
    const audio = new Audio(url);
    reel.audio = audio;
    audio.addEventListener("ended", () => URL.revokeObjectURL(url));
    await audio.play();
  }

  function openEditor(id, options) {
    const ann = state.annotations.find((item) => item.id === id);
    if (!ann) return;
    if (state.editor?.id === id) return;
    if (state.editor) void dismissEditor("outside");
    clearDraftAudio();
    state.editor = {
      id,
      fresh: Boolean(options.fresh),
      rect: options.rect || null,
      lastColorAtOpen: state.lastColor,
      audioRemoved: false,
      snapshot: { color: ann.color, sentiment: ann.sentiment, comment: ann.comment || "", hasAudio: ann.hasAudio }
    };
    ui.quote.textContent = preview(ann.quote, 180);
    ui.comment.value = ann.comment || "";
    ui.editor.hidden = false;
    updateEditorControls();
    updateAudioControls();
    placeEditor(id);
    hideHover();
    ui.comment.focus({ preventScroll: true });
  }

  async function dismissEditor(reason) {
    const editor = state.editor;
    if (!editor) return;
    const ann = state.annotations.find((item) => item.id === editor.id);
    if (reason === "save" && ann) {
      ann.comment = ui.comment.value;
      if (draftAudio) {
        await saveAudioBlob(ann.id, draftAudio);
        ann.hasAudio = true;
      } else if (editor.audioRemoved) {
        await deleteAudioBlob(ann.id);
        ann.hasAudio = false;
      }
      clearDraftAudio();
      closeEditor();
      persist();
      renderList();
      return;
    }
    if (reason === "cancel") {
      clearDraftAudio();
      if (editor.fresh) {
        state.lastColor = editor.lastColorAtOpen;
        await deleteAnnotation(editor.id);
        return;
      }
      if (ann) {
        ann.color = editor.snapshot.color;
        ann.sentiment = editor.snapshot.sentiment;
        state.lastColor = editor.lastColorAtOpen;
        persist();
        recolor(ann.id, displayColor(ann));
      }
      closeEditor();
      renderList();
      return;
    }
    clearDraftAudio();
    closeEditor();
  }

  async function deleteAnnotation(id) {
    if (state.editor?.id === id) {
      clearDraftAudio();
      closeEditor();
    }
    state.annotations = state.annotations.filter((ann) => ann.id !== id);
    if (state.hoverId === id) hideHover();
    await deleteAudioBlob(id);
    persist();
    syncMarks();
  }

  function chooseColor(color) {
    const ann = currentAnnotation();
    if (!ann || (color !== "yellow" && color !== "purple")) return;
    ann.color = color;
    state.lastColor = color;
    persist();
    recolor(ann.id, displayColor(ann));
    updateEditorControls();
    renderList();
  }

  function chooseSentiment(value) {
    const ann = currentAnnotation();
    if (!ann || !SENTIMENTS.includes(value)) return;
    ann.sentiment = ann.sentiment === value ? null : value;
    persist();
    recolor(ann.id, displayColor(ann));
    updateEditorControls();
    renderList();
    if (state.hoverId === ann.id) showHover(ann.id);
  }

  function jumpTo(id) {
    const ann = state.annotations.find((item) => item.id === id);
    if (!ann?.found) return;
    const behavior = motion();
    if (state.barOpen && state.annotationsVisible) {
      const marks = document.querySelectorAll(`span.tqa-ann-mark[data-ann-id="${CSS.escape(id)}"]`);
      if (marks.length) {
        marks[0].scrollIntoView({ block: "center", behavior });
        marks.forEach((mark) => mark.classList.add("tqa-ann-flash"));
        window.setTimeout(() => marks.forEach((mark) => mark.classList.remove("tqa-ann-flash")), 1200);
        return;
      }
    }
    const loc = state.locations[id];
    if (!loc || !state.index) return;
    const record = state.index.records.find((item) => item.start <= loc.start && item.end > loc.start);
    record?.node.parentElement?.scrollIntoView({ block: "center", behavior });
  }

  function sortedAnnotations() {
    return state.annotations
      .slice()
      .sort((a, b) => (a.pos ?? Infinity) - (b.pos ?? Infinity) || a.createdAt - b.createdAt);
  }

  function exportStamp() {
    return new Date().toISOString().slice(0, 10);
  }

  function exportTitle() {
    return document.title.trim() || location.hostname || "Page annotations";
  }

  function exportFilename(ext) {
    const host = (location.hostname || "page").replace(/[^a-z0-9.-]+/gi, "-");
    return `annotations-${host}-${exportStamp()}.${ext}`;
  }

  function annotationLines(ann, markdown) {
    const quote = (ann.quote || "").trim();
    const sentiment = sentimentLabel(sentimentOf(ann.sentiment));
    const colour = ann.color === "purple" ? "Purple" : "Yellow";
    const comment = (ann.comment || "").trim();
    if (markdown) {
      const quoted = quote.split("\n").map((line) => `> ${line}`).join("\n");
      const lines = ["## Highlight", "", quoted, "", `- Colour: ${colour}`];
      if (sentiment) lines.push(`- Sentiment: ${sentiment}`);
      if (comment) lines.push(`- Comment: ${comment}`);
      return lines.join("\n");
    }
    const lines = [quote, `Colour: ${colour}`];
    if (sentiment) lines.push(`Sentiment: ${sentiment}`);
    if (comment) lines.push(`Comment: ${comment}`);
    return lines.join("\n");
  }

  function buildMarkdown() {
    const notes = sortedAnnotations();
    const body = notes.map((ann) => annotationLines(ann, true)).join("\n\n");
    return `# ${exportTitle()}\n\nSource: ${location.href}\nExported: ${exportStamp()}\n\n${body}\n`;
  }

  function buildPlainText() {
    const notes = sortedAnnotations();
    const body = notes.map((ann, index) => `${index + 1}. ${annotationLines(ann, false)}`).join("\n\n");
    return `${exportTitle()}\nSource: ${location.href}\nExported: ${exportStamp()}\n\n${body}\n`;
  }

  const SHARE_BAR_CSS = `
#tqa-share-bar,
.tqa-ann-summary,
.tqa-ann-hover,
.tqa-ann-read-menu {
  pointer-events: auto;
}
#tqa-share-bar {
  position: fixed;
  z-index: 5;
  top: 0;
  left: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  box-sizing: border-box;
  min-height: 56px;
  padding: 10px 16px;
  background: #f5f0d3;
  border-bottom: 1px solid #e8e1be;
  box-shadow: 0 8px 24px rgba(26, 26, 58, 0.12);
}
#tqa-share-brand {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: 10px;
  min-width: 0;
}
#tqa-share-title {
  margin: 0;
  font-family: Literata, Georgia, "Times New Roman", serif;
  font-size: 22px;
  font-weight: 600;
  letter-spacing: -0.018em;
}
#tqa-share-stamp {
  margin: 0;
  font-size: 13px;
  font-weight: 400;
  font-style: italic;
  color: #4a4638;
  line-height: 1.3;
}
#tqa-share-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: none;
}
#tqa-share-source {
  color: #2b2b52;
  font: inherit;
  font-size: 14px;
  font-weight: 600;
  text-decoration: none;
}
#tqa-share-source:hover {
  text-decoration: underline;
}
`;

  let shareRuntimeText = "";

  async function loadShareRuntime() {
    if (!shareRuntimeText) {
      shareRuntimeText = await fetch(chrome.runtime.getURL("src/share-runtime.js")).then((response) => response.text());
    }
    return shareRuntimeText;
  }

  async function buildShareStyles() {
    const text = await loadCssText();
    const marker = "/* ==ui== */";
    const splitAt = text.indexOf(marker);
    const markCss = (splitAt === -1 ? text : text.slice(0, splitAt)).trim();
    const uiCss = (splitAt === -1 ? text : text.slice(splitAt + marker.length)).trim();
    return {
      markCss,
      uiCss: `${uiCss}\n${SHARE_BAR_CSS}`
    };
  }

  async function snapshotNotes() {
    const map = await getAudioMap();
    return sortedAnnotations().map((ann) => {
      const sentiment = sentimentOf(ann.sentiment);
      const audio = map[ann.id];
      return {
        id: ann.id,
        quote: ann.quote,
        color: displayColor(ann),
        sentiment: sentiment || "",
        sentimentLabel: sentimentLabel(sentiment),
        comment: (ann.comment || "").trim(),
        hasAudio: Boolean(audio?.data),
        audio: audio?.data ? { mime: audio.mime || "audio/webm", data: audio.data } : null
      };
    });
  }

  function sanitizeSnapshot(root) {
    root.querySelectorAll("script, noscript, #tqa-ann-host, #tqa-ann-mark-css, object, embed").forEach((el) => el.remove());
    root.querySelectorAll("meta").forEach((meta) => {
      const equiv = (meta.getAttribute("http-equiv") || "").toLowerCase();
      if (equiv === "content-security-policy" || equiv === "content-security-policy-report-only" || equiv === "refresh") meta.remove();
    });
    root.querySelectorAll("*").forEach((el) => {
      [...el.attributes].forEach((attr) => {
        const name = attr.name.toLowerCase();
        if (name.startsWith("on")) el.removeAttribute(attr.name);
        if ((name === "href" || name === "src" || name === "action" || name === "formaction" || name === "xlink:href") && /^\s*javascript:/i.test(attr.value)) {
          el.removeAttribute(attr.name);
        }
      });
      if (el.hasAttribute("srcdoc")) el.removeAttribute("srcdoc");
    });
  }

  function formatShareLabel(date = new Date()) {
    const when = date instanceof Date ? date : new Date(date);
    const pad = (value) => String(value).padStart(2, "0");
    const day = pad(when.getDate());
    const month = pad(when.getMonth() + 1);
    const year = when.getFullYear();
    const hours = pad(when.getHours());
    const minutes = pad(when.getMinutes());
    const zone = new Intl.DateTimeFormat("en-AU", { timeZoneName: "short" })
      .formatToParts(when)
      .find((part) => part.type === "timeZoneName")?.value || "";
    return `Shared on ${day}/${month}/${year} at ${hours}:${minutes} HRS${zone ? ` ${zone}` : ""}`;
  }

  async function inlineCssUrls(css) {
    const matches = [...css.matchAll(/url\("([^"]+)"\)/g)];
    const seen = new Set();
    let out = css;
    for (const match of matches) {
      const url = match[1];
      if (!url || url.startsWith("data:") || seen.has(url)) continue;
      seen.add(url);
      try {
        const response = await fetch(url);
        if (!response.ok) continue;
        const blob = await response.blob();
        const dataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || ""));
          reader.onerror = () => reject(reader.error);
          reader.readAsDataURL(blob);
        });
        out = out.split(`url("${url}")`).join(`url("${dataUrl}")`);
      } catch (error) {
        // Keep the original URL if a font cannot be inlined.
      }
    }
    return out;
  }

  async function buildHtmlPage(options = {}) {
    const painted = state.barOpen && state.annotationsVisible;
    if (!painted) paintAll();
    const clone = document.documentElement.cloneNode(true);
    if (!painted) {
      unwrapAll();
      refreshLocations();
    }
    sanitizeSnapshot(clone);
    const head = clone.querySelector("head") || clone.insertBefore(document.createElement("head"), clone.firstChild);
    const currentBase = clone.querySelector("base")?.getAttribute("href");
    clone.querySelectorAll("base").forEach((el) => el.remove());
    if (!head.querySelector("meta[charset]")) {
      const charset = document.createElement("meta");
      charset.setAttribute("charset", "utf-8");
      head.prepend(charset);
    }
    const base = document.createElement("base");
    base.setAttribute("href", new URL(currentBase || location.href, location.href).href);
    const charset = head.querySelector("meta[charset]");
    if (charset) charset.after(base);
    else head.prepend(base);
    const { markCss, uiCss } = await buildShareStyles();
    const markStyle = document.createElement("style");
    markStyle.textContent = markCss;
    head.append(markStyle);
    let html = `<!DOCTYPE html>\n${clone.outerHTML}`;
    const notes = await snapshotNotes();
    const runtime = await loadShareRuntime();
    const preparedUiCss = await inlineCssUrls(
      uiCss.replaceAll('url("../fonts/', `url("${chrome.runtime.getURL("fonts/")}`)
    );
    const payload = JSON.stringify({
      notes,
      shareId: options.shareId || "",
      apiBase: `${SUPABASE_URL}/rest/v1/rpc/`,
      apiKey: SUPABASE_KEY,
      sharedLabel: options.sharedLabel || ""
    }).replace(/</g, "\\u003c");
    const safeUiCss = preparedUiCss.replace(/<\/style/gi, "<\\/style");
    const injection = [
      `<style id="tqa-share-ui-css">${safeUiCss}</style>`,
      `<script type="application/json" id="tqa-ann-data">${payload}</script>`,
      `<script>${runtime}</script>`
    ].join("");
    const close = html.lastIndexOf("</body>");
    html = close === -1 ? html + injection : html.slice(0, close) + injection + html.slice(close);
    return html;
  }

  function setExportStatus(message) {
    if (!ui.toast) return;
    ui.toast.hidden = !message;
    ui.toast.textContent = message || "";
    window.clearTimeout(setExportStatus.timer);
    if (message) {
      setExportStatus.timer = window.setTimeout(() => {
        ui.toast.hidden = true;
        ui.toast.textContent = "";
      }, 4000);
    }
  }

  function setAuthStatus(message, kind) {
    if (!ui.authStatus) return;
    ui.authStatus.textContent = message || "";
    ui.authStatus.classList.toggle("is-error", kind === "error");
    ui.authStatus.classList.toggle("is-ok", kind === "ok");
  }

  function closeAccountMenu() {
    if (ui.accountWrap) ui.accountWrap.classList.remove("is-open");
    if (ui.accountButton && state.session) ui.accountButton.setAttribute("aria-expanded", "false");
  }

  function openAccountMenu() {
    ui.exportWrap?.classList.remove("is-open");
    ui.exportButton?.setAttribute("aria-expanded", "false");
    if (ui.accountWrap) ui.accountWrap.classList.add("is-open");
    if (ui.accountButton) ui.accountButton.setAttribute("aria-expanded", "true");
  }

  function openAccount(message, kind) {
    closeAccountMenu();
    ui.exportWrap?.classList.remove("is-open");
    ui.exportButton?.setAttribute("aria-expanded", "false");
    if (ui.accountScrim) ui.accountScrim.hidden = false;
    if (ui.account) ui.account.hidden = false;
    if (ui.accountButton && !state.session) ui.accountButton.setAttribute("aria-expanded", "true");
    setAuthStatus(message || "", kind || "");
  }

  function closeAccount() {
    if (ui.accountScrim) ui.accountScrim.hidden = true;
    if (ui.account) ui.account.hidden = true;
    if (ui.accountButton) {
      ui.accountButton.setAttribute("aria-expanded", state.session ? "false" : "false");
    }
    setAuthStatus("");
  }

  function syncAccountChrome() {
    const signedIn = Boolean(state.session);
    if (ui.accountButton) {
      ui.accountButton.textContent = signedIn ? "Account" : "Sign in";
      ui.accountButton.setAttribute("aria-haspopup", signedIn ? "menu" : "dialog");
    }
    if (ui.accountMenu) ui.accountMenu.hidden = !signedIn;
    if (!signedIn) closeAccountMenu();
  }

  function downloadInPage(filename, text, mime) {
    const url = URL.createObjectURL(new Blob([text], { type: `${mime};charset=utf-8` }));
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.style.display = "none";
    (document.body || document.documentElement).appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 20000);
  }

  function pageAddress() {
    return `${location.origin}${location.pathname}${location.search}`;
  }

  function shareLink(shareId) {
    // Vercel collapses "//" in paths, so encode the protocol as "https/host/path".
    const page = pageAddress().replace(/^https:\/\//i, "https/").replace(/^http:\/\//i, "http/");
    const url = new URL(`https://annotator.thequietachievr.com/${page}`);
    url.searchParams.set("share", shareId);
    return url.href;
  }

  async function sbRpc(name, args) {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${name}`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(args)
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      const message = data && (data.message || data.error || data.hint);
      throw new Error(message || `Annotator request failed (${response.status})`);
    }
    return data;
  }

  async function rememberShare(shareId) {
    const stored = await chrome.storage.local.get(SHARES_KEY);
    const shares = stored[SHARES_KEY] && typeof stored[SHARES_KEY] === "object" ? stored[SHARES_KEY] : {};
    shares[state.page] = shareId;
    await chrome.storage.local.set({ [SHARES_KEY]: shares });
    state.shareId = shareId;
  }

  function setAuthMode(mode) {
    state.authMode = mode;
    if (!ui.account) return;
    syncAccountChrome();
    const resetting = mode === "reset";
    const forgot = mode === "forgot";
    if (ui.authGuest) ui.authGuest.hidden = false;
    ui.authTitle.textContent = mode === "signup"
      ? "Create account"
      : forgot
        ? "Forgot password"
        : resetting
          ? "Set new password"
          : "Sign in";
    if (ui.authLead) {
      ui.authLead.textContent = mode === "signup"
        ? "Create an Annotator account to share pages with read receipts."
        : forgot
          ? "Enter your email to choose a new password."
          : resetting
            ? "Choose a new password for your account."
            : "Sign in to share annotated pages with read receipts.";
    }
    ui.authSubmit.textContent = mode === "signup"
      ? "Sign up"
      : forgot
        ? "Continue"
        : resetting
          ? "Save password"
          : "Sign in";
    if (ui.emailField) ui.emailField.hidden = resetting;
    ui.authEmail.required = !resetting;
    if (ui.passwordField) ui.passwordField.hidden = forgot;
    ui.authPassword.required = !forgot;
    ui.authPassword.placeholder = resetting ? "New password" : "Password";
    ui.authPassword.autocomplete = resetting || mode === "signup" ? "new-password" : "current-password";
    if (ui.passwordLabel) ui.passwordLabel.textContent = resetting ? "New password" : "Password";
    if (ui.confirmField) ui.confirmField.hidden = !resetting;
    ui.authConfirm.required = resetting;
    ui.forgotLink.hidden = mode !== "signin";
    if (ui.authSwitchWrap) ui.authSwitchWrap.hidden = resetting;
    if (mode === "signup" || forgot || resetting) {
      ui.authSwitch.textContent = "Sign in";
      ui.authSwitch.dataset.mode = "signin";
      if (ui.authSwitchText) ui.authSwitchText.textContent = "Already have an account?";
    } else {
      ui.authSwitch.textContent = "Sign up";
      ui.authSwitch.dataset.mode = "signup";
      if (ui.authSwitchText) ui.authSwitchText.textContent = "Don't have an account?";
    }
  }

  async function migrateLegacyKeys() {
    const stored = await chrome.storage.local.get(["tqaNotetakerSession", "tqaNotetakerShares", SESSION_KEY, SHARES_KEY]);
    const next = {};
    if (!stored[SESSION_KEY] && stored.tqaNotetakerSession) next[SESSION_KEY] = stored.tqaNotetakerSession;
    if (!stored[SHARES_KEY] && stored.tqaNotetakerShares) next[SHARES_KEY] = stored.tqaNotetakerShares;
    if (Object.keys(next).length) await chrome.storage.local.set(next);
  }

  async function loadNotetaker() {
    await migrateLegacyKeys();
    const stored = await chrome.storage.local.get([SESSION_KEY, SHARES_KEY]);
    state.session = stored[SESSION_KEY] || null;
    const shares = stored[SHARES_KEY] && typeof stored[SHARES_KEY] === "object" ? stored[SHARES_KEY] : {};
    state.shareId = shares[state.page] || null;
    if (!state.authMode) state.authMode = "signin";
    setAuthMode(state.session ? state.authMode : state.authMode || "signin");
    syncAccountChrome();
    if (state.shareId) await refreshReadState();
  }

  async function refreshReadState() {
    if (!state.shareId) return;
    const remote = await sbRpc("notetaker_state", { p_share: state.shareId });
    const next = {};
    (remote?.notes || []).forEach((note) => {
      next[note.local_id] = note.read_at || null;
    });
    const changed = JSON.stringify(next) !== JSON.stringify(state.readAt);
    state.readAt = next;
    if (changed && state.summaryOpen) renderList();
  }

  async function ensureAuthUser(email, password) {
    try {
      await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
        method: "POST",
        headers: {
          apikey: SUPABASE_KEY,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password })
      });
    } catch (error) {
      /* Auth user is only needed for password reset emails. */
    }
  }

  async function signIn(email, password) {
    const token = await sbRpc("notetaker_login", { p_email: email, p_password: password });
    if (!token) throw new Error("Incorrect email or password.");
    state.session = { token, email: email.trim().toLowerCase() };
    await chrome.storage.local.set({ [SESSION_KEY]: state.session });
    await loadNotetaker();
    closeAccount();
    setExportStatus("Signed in.");
  }

  async function signUp(email, password) {
    await ensureAuthUser(email, password);
    const token = await sbRpc("notetaker_signup", { p_email: email, p_password: password });
    if (!token) throw new Error("Could not create the account.");
    state.session = { token, email: email.trim().toLowerCase() };
    await chrome.storage.local.set({ [SESSION_KEY]: state.session });
    await loadNotetaker();
    closeAccount();
    setExportStatus("Account created.");
  }

  async function requestPasswordReset(email) {
    const response = await fetch(`${SUPABASE_URL}/functions/v1/notetaker-forgot`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.ok === false) {
      throw new Error(data.error || "Could not start the password reset.");
    }
    let token = "";
    if (data.reset_url) {
      try {
        token = new URL(data.reset_url).searchParams.get("token") || "";
      } catch (error) {
        token = "";
      }
    }
    if (!token) throw new Error("Could not start the password reset.");
    state.resetToken = token;
    setAuthMode("reset");
    openAccount("Choose a new password.", "ok");
  }

  async function completePasswordReset(password, confirm) {
    if (password.length < 8) throw new Error("Password must be at least 8 characters.");
    if (password !== confirm) throw new Error("Passwords do not match.");
    if (!state.resetToken) throw new Error("Start forgot password again.");
    const response = await fetch(`${SUPABASE_URL}/functions/v1/notetaker-reset`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ token: state.resetToken, password })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.ok === false) {
      throw new Error(data.error || "Could not update the password.");
    }
    state.resetToken = "";
    state.session = null;
    await chrome.storage.local.remove(SESSION_KEY);
    setAuthMode("signin");
    closeAccount();
    setExportStatus("Password updated. Sign in with your new password.");
  }

  async function signOut() {
    state.session = null;
    await chrome.storage.local.remove(SESSION_KEY);
    state.authMode = "signin";
    await loadNotetaker();
  }

  function showShareCopied(ok) {
    if (!ui.shareCopied || !ui.shareLinkItem) return;
    ui.shareCopied.hidden = !ok;
    ui.shareLinkItem.classList.toggle("is-copied", Boolean(ok));
    window.clearTimeout(showShareCopied.timer);
    if (ok) {
      showShareCopied.timer = window.setTimeout(() => {
        ui.shareCopied.hidden = true;
        ui.shareLinkItem.classList.remove("is-copied");
        ui.exportWrap?.classList.remove("is-open");
        ui.exportButton?.setAttribute("aria-expanded", "false");
      }, 1800);
    }
  }

  async function uploadShareSnapshot(shareId, html) {
    const response = await fetch(`${SUPABASE_URL}/functions/v1/notetaker-share-snapshot`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "text/html; charset=utf-8",
        "x-annotator-token": state.session.token,
        "x-share-id": shareId
      },
      body: html
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.ok === false) {
      throw new Error(data.error || "Could not upload the shared page.");
    }
  }

  async function publishShare() {
    if (!state.session?.token) {
      ui.exportWrap?.classList.remove("is-open");
      ui.exportButton?.setAttribute("aria-expanded", "false");
      setAuthMode("signin");
      openAccount("Sign in to create a share link.", "error");
      return;
    }
    if (!state.annotations.length) {
      setExportStatus("No annotations on this page.");
      return;
    }
    const result = await sbRpc("notetaker_publish", {
      p_token: state.session.token,
      p_page_url: pageAddress(),
      p_title: exportTitle().slice(0, 200),
      p_notes: sortedAnnotations().map((ann, position) => ({
        local_id: ann.id,
        quote: ann.quote,
        comment: ann.comment || "",
        sentiment: sentimentOf(ann.sentiment) || "",
        color: displayColor(ann),
        position
      }))
    });
    await rememberShare(result.share_id);
    try {
      const html = await buildHtmlPage({
        shareId: result.share_id,
        sharedLabel: formatShareLabel(new Date())
      });
      await uploadShareSnapshot(result.share_id, html);
    } catch (error) {
      setExportStatus(error instanceof Error ? error.message : "Could not prepare the shared page.");
      showShareCopied(false);
      return;
    }
    const url = shareLink(result.share_id);
    try {
      await navigator.clipboard.writeText(url);
      showShareCopied(true);
    } catch (error) {
      setExportStatus("Could not copy the share link.");
      showShareCopied(false);
    }
    await refreshReadState();
    renderList();
  }

  async function setNoteRead(id, read) {
    if (!state.shareId) return;
    await sbRpc("notetaker_set_read", { p_share: state.shareId, p_local_id: id, p_read: read });
    state.readAt[id] = read ? new Date().toISOString() : null;
    renderList();
  }

  function showReadMenu(event, ann) {
    if (!state.shareId || !ui.readMenu) return;
    event.preventDefault();
    event.stopPropagation();
    ui.readMenu.hidden = false;
    ui.readMenu.style.left = `${event.clientX}px`;
    ui.readMenu.style.top = `${event.clientY}px`;
    ui.readMenu.dataset.id = ann.id;
    ui.readMenuButton.textContent = state.readAt[ann.id] ? "Mark as unread" : "Mark as read";
  }

  function sendToExtension(message) {
    return new Promise((resolve) => {
      if (!extensionAlive()) {
        retire();
        resolve({ ok: false, error: "Reload this page after updating Annotator." });
        return;
      }
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) {
            const error = chrome.runtime.lastError.message || "Export failed.";
            if (/context invalidated/i.test(error)) retire();
            resolve({ ok: false, error: /context invalidated/i.test(error) ? "Reload this page after updating Annotator." : error });
            return;
          }
          resolve(response || { ok: false, error: "Export failed." });
        });
      } catch (error) {
        if (isContextError(error)) retire(error);
        resolve({ ok: false, error: "Reload this page after updating Annotator." });
      }
    });
  }

  async function runExport(format) {
    if (!state.annotations.length) {
      setExportStatus("No annotations on this page.");
      return;
    }
    if (format === "html") {
      setExportStatus("Preparing HTML page…");
      let html = "";
      try {
        html = await buildHtmlPage();
      } catch (error) {
        setExportStatus("Could not prepare the HTML page.");
        return;
      }
      try {
        downloadInPage(exportFilename("html"), html, "text/html");
      } catch (error) {
        setExportStatus(error instanceof Error ? error.message : "Download failed.");
        return;
      }
      setExportStatus("Downloading HTML page.");
      return;
    }
    if (format === "notion") {
      setExportStatus("Saving to Notion…");
      const result = await sendToExtension({
        type: "tqa-ann-export-notion",
        title: exportTitle().slice(0, 200),
        url: location.href,
        summary: `${state.annotations.length} annotation${state.annotations.length === 1 ? "" : "s"} from ${location.hostname}`.slice(0, 2000),
        markdown: buildMarkdown()
      });
      setExportStatus(result.ok ? "Saved to Notion." : result.error || "Notion export failed.");
      return;
    }
    const ext = format === "txt" ? "txt" : "md";
    const result = await sendToExtension({
      type: "tqa-ann-export-file",
      ext,
      filename: exportFilename(ext),
      text: ext === "txt" ? buildPlainText() : buildMarkdown()
    });
    setExportStatus(result.ok ? `Downloading ${ext === "txt" ? "text" : "Markdown"} file.` : result.error || "Download failed.");
  }

  function setSummary(open) {
    state.summaryOpen = open;
    if (open) void dismissEditor("outside");
    renderVisibility();
  }

  async function toggleBar() {
    if (state.barOpen) {
      void dismissEditor("outside");
      state.barOpen = false;
      state.summaryOpen = false;
      hideHover();
    } else {
      await ensureUiCss();
      state.barOpen = true;
    }
    syncMarks();
    renderVisibility();
    applyOpacity();
  }

  function createFromRange(range) {
    if (shouldSkipNode(range.startContainer) || shouldSkipNode(range.endContainer)) return;
    const elementOf = (node) => (node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement);
    if (elementOf(range.startContainer)?.closest(".tqa-ann-mark") || elementOf(range.endContainer)?.closest(".tqa-ann-mark")) return;
    const index = buildIndex();
    const start = offsetOfPoint(index, range.startContainer, range.startOffset);
    const end = offsetOfPoint(index, range.endContainer, range.endOffset);
    if (start == null || end == null || end <= start) return;
    const quote = index.text.slice(start, end);
    if (!quote.trim()) return;
    const existing = TqaAnchor.assignLocations(index.text, state.annotations);
    const blocked = Object.values(existing).some((loc) => loc && start < loc.end && loc.start < end);
    if (blocked) return;
    const ann = {
      id: newId(),
      quote,
      prefix: index.text.slice(Math.max(0, start - TqaAnchor.CONTEXT), start),
      suffix: index.text.slice(end, end + TqaAnchor.CONTEXT),
      color: state.lastColor === "purple" ? "purple" : "yellow",
      sentiment: null,
      comment: "",
      createdAt: Date.now(),
      hasAudio: false,
      hint: start
    };
    const rect = range.getBoundingClientRect();
    state.annotations.push(ann);
    persist();
    syncMarks();
    window.getSelection()?.removeAllRanges();
    openEditor(ann.id, { fresh: true, rect });
  }

  function closestMark(target) {
    if (!(target instanceof Element)) return null;
    return target.closest("span.tqa-ann-mark");
  }

  function pathHas(path, className) {
    return path.some((node) => node instanceof Element && node.classList.contains(className));
  }

  function onMouseUp(event) {
    if (retired) return;
    if (!extensionAlive()) {
      retire();
      return;
    }
    if (!state.barOpen || event.button !== 0) return;
    if (event.composedPath().includes(ui.host)) return;
    const selection = window.getSelection();
    const selected = selection && !selection.isCollapsed ? selection.toString() : "";
    if (selected.trim()) {
      if (selection.rangeCount) createFromRange(selection.getRangeAt(0));
      return;
    }
    const mark = closestMark(event.target);
    if (!mark) return;
    openEditor(mark.dataset.annId, { fresh: false });
  }

  let summaryGesture = null;

  function beginSummaryGesture(type, edge, event) {
    event.preventDefault();
    summaryGesture = {
      type,
      edge,
      startX: event.clientX,
      startY: event.clientY,
      frame: { ...(state.summaryFrame || defaultFrame()) }
    };
  }

  function onSummaryGestureMove(event) {
    if (!summaryGesture) return;
    const dx = event.clientX - summaryGesture.startX;
    const dy = event.clientY - summaryGesture.startY;
    const start = summaryGesture.frame;
    const next = { ...start };
    if (summaryGesture.type === "move") {
      next.left = start.left + dx;
      next.top = start.top + dy;
    } else {
      const edge = summaryGesture.edge;
      if (edge.includes("e")) next.width = start.width + dx;
      if (edge.includes("s")) next.height = start.height + dy;
      if (edge.includes("w")) {
        next.width = start.width - dx;
        next.left = start.left + dx;
      }
      if (edge.includes("n")) {
        next.height = start.height - dy;
        next.top = start.top + dy;
      }
    }
    state.summaryFrame = clampFrame(next, summaryGesture.type === "resize" ? edgeOf(summaryGesture) : "");
    applyFrame();
  }

  function edgeOf(gesture) {
    return gesture.edge || "";
  }

  function onSummaryGestureEnd() {
    if (!summaryGesture) return;
    summaryGesture = null;
    persist();
  }

  function onMouseDown(event) {
    if (retired) return;
    if (!extensionAlive()) {
      retire();
      return;
    }
    if (event.button !== 0) return;
    const path = event.composedPath();
    if (state.editor && !pathHas(path, "tqa-ann-editor")) {
      const mark = closestMark(event.target);
      if (!(mark && mark.dataset.annId === state.editor.id)) void dismissEditor("outside");
    }
    if (ui.readMenu && !pathHas(path, "tqa-ann-read-menu")) ui.readMenu.hidden = true;
    if (ui.exportWrap && !pathHas(path, "tqa-ann-export")) {
      ui.exportWrap.classList.remove("is-open");
      ui.exportButton.setAttribute("aria-expanded", "false");
    }
    if (ui.accountWrap && !pathHas(path, "tqa-ann-account-wrap")) closeAccountMenu();
  }

  function onUiClick(event) {
    const trigger = event.target instanceof Element ? event.target.closest("[data-action]") : null;
    if (!trigger) return;
    const action = trigger.dataset.action;
    if (action === "toggle-annotations") {
      void dismissEditor("outside");
      state.annotationsVisible = !state.annotationsVisible;
      persist();
      hideHover();
      syncMarks();
      renderVisibility();
      return;
    }
    if (action === "toggle-summary") {
      setSummary(!state.summaryOpen);
      return;
    }
    if (action === "toggle-export") {
      closeAccountMenu();
      const open = !ui.exportWrap.classList.contains("is-open");
      ui.exportWrap.classList.toggle("is-open", open);
      ui.exportButton.setAttribute("aria-expanded", String(open));
      return;
    }
    if (action === "export") {
      ui.exportWrap.classList.remove("is-open");
      ui.exportButton.setAttribute("aria-expanded", "false");
      void runExport(trigger.dataset.format);
      return;
    }
    if (action === "toggle-account") {
      if (state.session) {
        if (ui.accountWrap?.classList.contains("is-open")) closeAccountMenu();
        else openAccountMenu();
        return;
      }
      if (ui.account.hidden) {
        setAuthMode(state.authMode || "signin");
        openAccount();
      } else {
        closeAccount();
      }
      return;
    }
    if (action === "close-account") {
      closeAccount();
      return;
    }
    if (action === "change-password") {
      closeAccountMenu();
      if (!state.session?.email) return;
      void requestPasswordReset(state.session.email)
        .then(() => setAuthStatus("Choose a new password.", "ok"))
        .catch((error) => {
          setAuthMode("forgot");
          openAccount(error instanceof Error ? error.message : "Could not start the password change.", "error");
        });
      return;
    }
    if (action === "sign-out") {
      closeAccountMenu();
      void signOut().then(() => {
        setAuthMode("signin");
        setExportStatus("Signed out.");
      });
      return;
    }
    if (action === "share-link") {
      ui.exportWrap.classList.add("is-open");
      ui.exportButton.setAttribute("aria-expanded", "true");
      void publishShare().catch((error) => {
        showShareCopied(false);
        setExportStatus(error.message || "Could not create the share link.");
      });
      return;
    }
    if (action === "toggle-read") {
      const id = ui.readMenu.dataset.id;
      ui.readMenu.hidden = true;
      void setNoteRead(id, !state.readAt[id]).catch((error) => setExportStatus(error.message || "Could not update read status."));
      return;
    }
    if (action === "close-summary") {
      setSummary(false);
      return;
    }
    if (action === "save") {
      void dismissEditor("save");
      return;
    }
    if (action === "cancel") {
      void dismissEditor("cancel");
      return;
    }
    if (action === "delete") {
      if (state.editor) void deleteAnnotation(state.editor.id);
      return;
    }
    if (action === "record") {
      void toggleRecording();
      return;
    }
    if (action === "play-draft") {
      void playDraftOrSaved();
      return;
    }
    if (action === "restart-draft") {
      clearDraftAudio();
      if (state.editor) state.editor.audioRemoved = Boolean(currentAnnotation()?.hasAudio);
      updateAudioControls();
      return;
    }
    if (action === "delete-audio") {
      clearDraftAudio();
      if (state.editor) state.editor.audioRemoved = true;
      updateAudioControls();
      return;
    }
    if (action === "play-all") {
      void togglePlayAll();
      return;
    }
    if (action === "play-one") {
      void playOne(trigger.dataset.id);
      return;
    }
    if (action === "auth-switch") {
      setAuthStatus("");
      setAuthMode(trigger.dataset.mode === "signup" ? "signup" : "signin");
      return;
    }
    if (action === "forgot-password") {
      setAuthStatus("");
      setAuthMode("forgot");
      return;
    }
    if (action === "color") {
      chooseColor(trigger.dataset.color);
      return;
    }
    if (action === "sentiment") {
      chooseSentiment(trigger.dataset.sentiment);
      return;
    }
    if (action === "filter") {
      state.filters[trigger.dataset.filter] = trigger.dataset.value;
      renderList();
      return;
    }
    if (action === "jump") {
      const paragraph = event.target instanceof Element
        ? event.target.closest(".tqa-ann-quote, .tqa-ann-comment-preview")
        : null;
      if (paragraph && canRevealParagraph(paragraph, trigger.dataset.id)) {
        toggleParagraph(paragraph, trigger.dataset.id);
        return;
      }
      jumpTo(trigger.dataset.id);
    }
  }

  function onKeyDown(event) {
    if (retired) return;
    if (!extensionAlive()) {
      retire();
      return;
    }
    if (event.key === "Enter" && (event.metaKey || event.ctrlKey) && event.target === ui.comment) {
      event.preventDefault();
      void dismissEditor("save");
      return;
    }
    if (event.key !== "Escape") return;
    if (ui.account && !ui.account.hidden) {
      event.preventDefault();
      event.stopPropagation();
      closeAccount();
      return;
    }
    if (!state.editor && !state.summaryOpen) return;
    event.preventDefault();
    event.stopPropagation();
    if (state.editor) void dismissEditor("cancel");
    else setSummary(false);
  }

  async function loadCssText() {
    if (!cssText) cssText = await fetch(chrome.runtime.getURL("src/content.css")).then((response) => response.text());
    return cssText;
  }

  async function injectMarkCss() {
    if (document.getElementById("tqa-ann-mark-css")) return;
    const text = await loadCssText();
    const marker = "/* ==ui== */";
    const splitAt = text.indexOf(marker);
    const style = document.createElement("style");
    style.id = "tqa-ann-mark-css";
    style.textContent = splitAt === -1 ? text : text.slice(0, splitAt);
    document.documentElement.appendChild(style);
  }

  async function ensureUiCss() {
    if (uiCssReady) return;
    const text = await loadCssText();
    const marker = "/* ==ui== */";
    const splitAt = text.indexOf(marker);
    const uiCss = (splitAt === -1 ? text : text.slice(splitAt + marker.length)).replaceAll(
      'url("../fonts/',
      `url("${chrome.runtime.getURL("fonts/")}`
    );
    ui.styleEl.textContent = uiCss;
    uiCssReady = true;
  }

  function mount() {
    const host = document.createElement("div");
    host.id = "tqa-ann-host";
    Object.entries({
      position: "fixed",
      inset: "0",
      width: "100%",
      height: "100%",
      "z-index": "2147483647",
      "pointer-events": "none",
      border: "0",
      margin: "0",
      padding: "0",
      background: "transparent"
    }).forEach(([key, value]) => host.style.setProperty(key, value, "important"));
    document.documentElement.appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });
    const styleEl = document.createElement("style");
    const root = document.createElement("div");
    root.className = "tqa-ann-root";
    shadow.append(styleEl, root);
    root.innerHTML = `
      <header class="tqa-ann-bar" hidden>
        <div class="tqa-ann-brand">
          <h1 class="tqa-ann-title">Annotator</h1>
          <a class="tqa-ann-feedback" href="mailto:annotator@thequietachievr.com?subject=Annotator%20feedback%20and%20suggestions">Send feedback/<em>suggestions</em></a>
        </div>
        <div class="tqa-ann-bar-actions">
          <span class="tqa-ann-switch-label">
            <button type="button" class="tqa-ann-switch" data-action="toggle-annotations" role="switch" aria-checked="true" aria-label="Show annotations"></button>
            Annotations
          </span>
          <div class="tqa-ann-export">
            <button type="button" class="tqa-ann-btn tqa-ann-btn-secondary" data-action="toggle-export" aria-expanded="false" aria-haspopup="menu">Export...</button>
            <div class="tqa-ann-export-menu" role="menu">
              <div class="tqa-ann-export-menu-inner">
                <button type="button" role="menuitem" data-action="export" data-format="md">Markdown (.md)</button>
                <button type="button" role="menuitem" data-action="export" data-format="txt">Text (.txt)</button>
                <button type="button" role="menuitem" data-action="export" data-format="html">HTML page (.html)</button>
                <button type="button" role="menuitem" data-action="export" data-format="notion">Notion</button>
                <button type="button" role="menuitem" class="tqa-ann-share-item" data-action="share-link">
                  <span class="tqa-ann-share-item-label">Share link</span>
                  <span class="tqa-ann-share-copied" hidden>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M9.2 16.6 4.8 12.2l1.4-1.4 3 3 8.6-8.6 1.4 1.4z"/></svg>
                    Copied
                  </span>
                </button>
              </div>
            </div>
          </div>
          <button type="button" class="tqa-ann-btn tqa-ann-btn-secondary" data-action="toggle-summary" aria-expanded="false">Summary</button>
          <div class="tqa-ann-account-wrap">
            <button type="button" class="tqa-ann-btn tqa-ann-btn-secondary" data-action="toggle-account" aria-expanded="false" aria-haspopup="dialog">Sign in</button>
            <div class="tqa-ann-account-menu" role="menu" hidden>
              <div class="tqa-ann-export-menu-inner">
                <button type="button" role="menuitem" data-action="change-password">Change password</button>
                <button type="button" role="menuitem" data-action="sign-out">Sign out</button>
              </div>
            </div>
          </div>
        </div>
      </header>
      <p class="tqa-ann-toast" role="status" aria-live="polite" hidden></p>
      <div class="tqa-ann-account-scrim" data-action="close-account" hidden></div>
      <section class="tqa-ann-account" role="dialog" aria-modal="true" aria-labelledby="tqa-ann-auth-title" hidden>
        <div class="tqa-ann-account-head">
          <h2 class="tqa-ann-auth-title" id="tqa-ann-auth-title">Sign in</h2>
          <button type="button" class="tqa-ann-account-close" data-action="close-account" aria-label="Close">×</button>
        </div>
        <p class="tqa-ann-auth-lead">Sign in to share annotated pages with read receipts.</p>
        <p class="tqa-ann-auth-status" role="status" aria-live="polite"></p>
        <div class="tqa-ann-auth-guest">
          <form class="tqa-ann-login">
            <div class="tqa-ann-field tqa-ann-email-field">
              <label class="tqa-ann-field-label" for="tqa-ann-email">Email</label>
              <input id="tqa-ann-email" type="email" name="email" autocomplete="username" required placeholder="you@example.com">
            </div>
            <div class="tqa-ann-field tqa-ann-password-field">
              <div class="tqa-ann-field-label-row">
                <label class="tqa-ann-password-label" for="tqa-ann-password">Password</label>
                <button type="button" class="tqa-ann-link" data-action="forgot-password">Forgot password?</button>
              </div>
              <input id="tqa-ann-password" type="password" name="password" autocomplete="current-password" required placeholder="Password">
            </div>
            <div class="tqa-ann-field tqa-ann-confirm-field" hidden>
              <label class="tqa-ann-field-label" for="tqa-ann-confirm">Confirm password</label>
              <input id="tqa-ann-confirm" type="password" name="confirm" autocomplete="new-password" placeholder="Confirm password">
            </div>
            <button type="submit" class="tqa-ann-btn tqa-ann-btn-primary">Sign in</button>
          </form>
          <div class="tqa-ann-auth-footer">
            <p class="tqa-ann-auth-switch"><span class="tqa-ann-auth-switch-text">Don't have an account?</span> <button type="button" class="tqa-ann-link" data-action="auth-switch" data-mode="signup">Sign up</button></p>
          </div>
        </div>
      </section>
      <menu class="tqa-ann-read-menu" hidden>
        <button type="button" data-action="toggle-read">Mark as unread</button>
      </menu>
      <aside class="tqa-ann-summary" role="dialog" aria-label="Annotation summary" hidden>
        <div class="tqa-ann-resize" data-resize="n"></div>
        <div class="tqa-ann-resize" data-resize="s"></div>
        <div class="tqa-ann-resize" data-resize="e"></div>
        <div class="tqa-ann-resize" data-resize="w"></div>
        <div class="tqa-ann-resize" data-resize="nw"></div>
        <div class="tqa-ann-resize" data-resize="ne"></div>
        <div class="tqa-ann-resize" data-resize="sw"></div>
        <div class="tqa-ann-resize" data-resize="se"></div>
        <div class="tqa-ann-summary-head">
          <div class="tqa-ann-summary-title-row">
            <div>
              <h2 class="tqa-ann-summary-title">Summary</h2>
              <p class="tqa-ann-count"></p>
            </div>
            <button type="button" class="tqa-ann-btn tqa-ann-btn-secondary" data-action="close-summary">Close</button>
          </div>
          <label class="tqa-ann-slider">
            <span class="tqa-ann-slider-row"><span>Transparency</span><span class="tqa-ann-opacity-label"></span></span>
            <input id="tqa-ann-opacity" type="range" min="0" max="100" value="100" aria-label="Summary panel opacity">
          </label>
        </div>
        <div class="tqa-ann-summary-body">
          <div class="tqa-ann-filter">
            <p class="tqa-ann-eyebrow">Feedback</p>
            <div class="tqa-ann-segment" role="group" aria-label="Feedback">
              <button type="button" data-action="filter" data-filter="sentiment" data-value="all" aria-pressed="true">All</button>
              <button type="button" data-action="filter" data-filter="sentiment" data-value="positive">Positive</button>
              <button type="button" data-action="filter" data-filter="sentiment" data-value="suggestion">Suggestion</button>
              <button type="button" data-action="filter" data-filter="sentiment" data-value="neutral">Neutral</button>
              <button type="button" data-action="filter" data-filter="sentiment" data-value="none">None</button>
            </div>
          </div>
          <div class="tqa-ann-filter">
            <p class="tqa-ann-eyebrow">Highlight</p>
            <div class="tqa-ann-segment" role="group" aria-label="Highlight">
              <button type="button" data-action="filter" data-filter="color" data-value="all" aria-pressed="true">All</button>
              <button type="button" data-action="filter" data-filter="color" data-value="yellow">Yellow</button>
              <button type="button" data-action="filter" data-filter="color" data-value="purple">Purple</button>
            </div>
          </div>
          <div class="tqa-ann-filter">
            <p class="tqa-ann-eyebrow">Comment</p>
            <div class="tqa-ann-segment" role="group" aria-label="Comment">
              <button type="button" data-action="filter" data-filter="comment" data-value="all" aria-pressed="true">All</button>
              <button type="button" data-action="filter" data-filter="comment" data-value="with">With comment</button>
              <button type="button" data-action="filter" data-filter="comment" data-value="without">Without comment</button>
            </div>
          </div>
          <button type="button" class="tqa-ann-btn tqa-ann-btn-primary tqa-ann-play-all" data-action="play-all">Play All</button>
          <p class="tqa-ann-empty" hidden></p>
          <ul class="tqa-ann-list"></ul>
        </div>
      </aside>
      <aside class="tqa-ann-hover" hidden>
        <p class="tqa-ann-hover-quote"></p>
        <span class="tqa-ann-tag" hidden></span>
        <p class="tqa-ann-hover-comment" hidden></p>
      </aside>
      <section class="tqa-ann-editor" role="dialog" aria-label="Annotation" hidden>
        <p class="tqa-ann-editor-quote"></p>
        <div class="tqa-ann-field">
          <p class="tqa-ann-eyebrow">Highlight colour</p>
          <div class="tqa-ann-swatches">
            <button type="button" class="tqa-ann-swatch" data-action="color" data-color="yellow" aria-label="Yellow" aria-pressed="true"></button>
            <button type="button" class="tqa-ann-swatch" data-action="color" data-color="purple" aria-label="Purple" aria-pressed="false"></button>
          </div>
        </div>
        <div class="tqa-ann-field">
          <p class="tqa-ann-eyebrow">Feedback</p>
          <div class="tqa-ann-sentiments">
            <button type="button" class="tqa-ann-sentiment" data-action="sentiment" data-sentiment="positive" aria-pressed="false">Positive</button>
            <button type="button" class="tqa-ann-sentiment" data-action="sentiment" data-sentiment="suggestion" aria-pressed="false">Suggestion</button>
            <button type="button" class="tqa-ann-sentiment" data-action="sentiment" data-sentiment="neutral" aria-pressed="false">Neutral</button>
          </div>
        </div>
        <div class="tqa-ann-field">
          <label class="tqa-ann-eyebrow" for="tqa-ann-comment">Comment</label>
          <textarea id="tqa-ann-comment" class="tqa-ann-comment" maxlength="4000" placeholder="Add a comment"></textarea>
        </div>
        <div class="tqa-ann-field tqa-ann-audio">
          <p class="tqa-ann-eyebrow">Audio</p>
          <div class="tqa-ann-audio-controls">
            <button type="button" class="tqa-ann-btn tqa-ann-btn-secondary" data-action="record">Record</button>
            <button type="button" class="tqa-ann-icon-btn" data-action="play-draft" hidden aria-label="Play"></button>
            <button type="button" class="tqa-ann-icon-btn" data-action="restart-draft" hidden aria-label="Restart"></button>
            <button type="button" class="tqa-ann-icon-btn" data-action="delete-audio" hidden aria-label="Delete recording"></button>
          </div>
          <p class="tqa-ann-audio-status"></p>
        </div>
        <div class="tqa-ann-editor-actions">
          <div class="tqa-ann-editor-actions-main">
            <button type="button" class="tqa-ann-btn tqa-ann-btn-primary" data-action="save">Save</button>
            <button type="button" class="tqa-ann-btn tqa-ann-btn-secondary" data-action="cancel">Cancel</button>
          </div>
          <button type="button" class="tqa-ann-btn tqa-ann-btn-ghost" data-action="delete">Delete</button>
        </div>
      </section>
    `;

    ui.host = host;
    ui.styleEl = styleEl;
    ui.root = root;
    ui.bar = root.querySelector(".tqa-ann-bar");
    ui.toggle = root.querySelector(".tqa-ann-switch");
    ui.summaryButton = root.querySelector("[data-action='toggle-summary']");
    ui.exportWrap = root.querySelector(".tqa-ann-export");
    ui.exportButton = root.querySelector("[data-action='toggle-export']");
    ui.shareLinkItem = root.querySelector("[data-action='share-link']");
    ui.shareCopied = root.querySelector(".tqa-ann-share-copied");
    ui.toast = root.querySelector(".tqa-ann-toast");
    ui.accountScrim = root.querySelector(".tqa-ann-account-scrim");
    ui.account = root.querySelector(".tqa-ann-account");
    ui.accountWrap = root.querySelector(".tqa-ann-account-wrap");
    ui.accountMenu = root.querySelector(".tqa-ann-account-menu");
    ui.accountButton = root.querySelector("[data-action='toggle-account']");
    ui.authGuest = root.querySelector(".tqa-ann-auth-guest");
    ui.authForm = root.querySelector(".tqa-ann-login");
    ui.authTitle = root.querySelector(".tqa-ann-auth-title");
    ui.authLead = root.querySelector(".tqa-ann-auth-lead");
    ui.authStatus = root.querySelector(".tqa-ann-auth-status");
    ui.authSubmit = root.querySelector(".tqa-ann-login button[type='submit']");
    ui.emailField = root.querySelector(".tqa-ann-email-field");
    ui.passwordField = root.querySelector(".tqa-ann-password-field");
    ui.confirmField = root.querySelector(".tqa-ann-confirm-field");
    ui.passwordLabel = root.querySelector(".tqa-ann-password-label");
    ui.authEmail = root.querySelector(".tqa-ann-login input[name='email']");
    ui.authPassword = root.querySelector(".tqa-ann-login input[name='password']");
    ui.authConfirm = root.querySelector(".tqa-ann-login input[name='confirm']");
    ui.authSwitch = root.querySelector("[data-action='auth-switch']");
    ui.authSwitchWrap = root.querySelector(".tqa-ann-auth-switch");
    ui.authSwitchText = root.querySelector(".tqa-ann-auth-switch-text");
    ui.forgotLink = root.querySelector("[data-action='forgot-password']");
    ui.readMenu = root.querySelector(".tqa-ann-read-menu");
    ui.readMenuButton = root.querySelector(".tqa-ann-read-menu button");
    ui.summary = root.querySelector(".tqa-ann-summary");
    ui.summaryBody = root.querySelector(".tqa-ann-summary-body");
    ui.playAllButton = root.querySelector("[data-action='play-all']");
    ui.recordButton = root.querySelector("[data-action='record']");
    ui.playDraftButton = root.querySelector("[data-action='play-draft']");
    ui.restartDraftButton = root.querySelector("[data-action='restart-draft']");
    ui.deleteAudioButton = root.querySelector("[data-action='delete-audio']");
    ui.audioStatus = root.querySelector(".tqa-ann-audio-status");
    ui.count = root.querySelector(".tqa-ann-count");
    ui.opacity = root.querySelector("#tqa-ann-opacity");
    ui.opacityLabel = root.querySelector(".tqa-ann-opacity-label");
    ui.empty = root.querySelector(".tqa-ann-empty");
    ui.list = root.querySelector(".tqa-ann-list");
    ui.hover = root.querySelector(".tqa-ann-hover");
    ui.hoverQuote = root.querySelector(".tqa-ann-hover-quote");
    ui.hoverTag = root.querySelector(".tqa-ann-hover .tqa-ann-tag");
    ui.hoverComment = root.querySelector(".tqa-ann-hover-comment");
    ui.editor = root.querySelector(".tqa-ann-editor");
    ui.quote = root.querySelector(".tqa-ann-editor-quote");
    ui.comment = root.querySelector("#tqa-ann-comment");

    root.addEventListener("click", onUiClick);
    ui.authForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(ui.authForm);
      const email = String(data.get("email") || "");
      const password = String(data.get("password") || "");
      ui.authSubmit.disabled = true;
      const done = () => {
        ui.authSubmit.disabled = false;
      };
      if (state.authMode === "signup") {
        void signUp(email, password)
          .catch((error) => setAuthStatus(error instanceof Error ? error.message : "Could not sign up.", "error"))
          .finally(done);
        return;
      }
      if (state.authMode === "forgot") {
        void requestPasswordReset(email)
          .then(() => setAuthStatus("Choose a new password.", "ok"))
          .catch((error) => setAuthStatus(error instanceof Error ? error.message : "Could not start the password reset.", "error"))
          .finally(done);
        return;
      }
      if (state.authMode === "reset") {
        const confirm = String(data.get("confirm") || "");
        void completePasswordReset(password, confirm)
          .catch((error) => setAuthStatus(error instanceof Error ? error.message : "Could not update the password.", "error"))
          .finally(done);
        return;
      }
      void signIn(email, password)
        .catch((error) => setAuthStatus(error instanceof Error ? error.message : "Could not sign in.", "error"))
        .finally(done);
    });
    sharePoll = window.setInterval(() => {
      if (!extensionAlive()) {
        retire();
        return;
      }
      if (!state.shareId || !state.barOpen) return;
      void refreshReadState().catch((error) => {
        if (isContextError(error)) retire(error);
      });
    }, 5000);
    root.querySelector(".tqa-ann-switch-label").addEventListener("click", (event) => {
      if (event.target instanceof Element && event.target.closest(".tqa-ann-switch")) return;
      ui.toggle.click();
    });
    root.addEventListener("keydown", onKeyDown);
    ui.opacity.addEventListener("input", () => {
      state.summaryOpacity = clampOpacity(ui.opacity.value);
      applyOpacity();
    });
    ui.opacity.addEventListener("change", () => persist());
    root.querySelector(".tqa-ann-summary-title-row").addEventListener("mousedown", (event) => {
      if (event.button !== 0) return;
      if (event.target instanceof Element && event.target.closest("button, a, input")) return;
      beginSummaryGesture("move", "", event);
    });
    root.querySelectorAll("[data-resize]").forEach((handle) => {
      handle.addEventListener("mousedown", (event) => {
        if (event.button !== 0) return;
        event.stopPropagation();
        beginSummaryGesture("resize", handle.dataset.resize, event);
      });
    });
  }

  function hookHistory() {
    const fire = () => queueMicrotask(onUrlMaybeChanged);
    // Isolated-world wraps miss page SPA calls; MAIN world history-hook posts instead.
    ["pushState", "replaceState"].forEach((name) => {
      const original = history[name];
      if (!original || original.__tqaAnn) return;
      const wrapped = function wrappedHistory(...args) {
        const result = original.apply(this, args);
        fire();
        return result;
      };
      wrapped.__tqaAnn = true;
      history[name] = wrapped;
    });
    window.addEventListener("popstate", fire);
    window.addEventListener("hashchange", fire);
    window.addEventListener("message", (event) => {
      if (event.source !== window || !event.data || event.data.type !== "tqa-ann-url") return;
      fire();
    });
    if (window.navigation && typeof window.navigation.addEventListener === "function") {
      try {
        window.navigation.addEventListener("navigate", fire);
      } catch (error) {
        /* Navigation API may reject in some contexts */
      }
    }
    window.setInterval(fire, 500);
  }

  let urlLock = Promise.resolve();

  function onUrlMaybeChanged() {
    urlLock = urlLock.then(async () => {
      const next = TqaAnchor.pageKeyFromHref(location.href);
      if (next === state.page) return;
      void dismissEditor("outside");
      hideHover();
      if (ui.readMenu) ui.readMenu.hidden = true;
      await persist();
      if (!memory) memory = await readStore();
      state.page = next;
      state.annotations = annotationsFromMemory(next);
      state.readAt = {};
      const shareStore = await chrome.storage.local.get(SHARES_KEY);
      const shares = shareStore[SHARES_KEY] && typeof shareStore[SHARES_KEY] === "object" ? shareStore[SHARES_KEY] : {};
      state.shareId = shares[next] || null;
      if (state.shareId) await refreshReadState();
      await refreshAudioFlags();
      syncMarks();
      renderVisibility();
      renderList();
    }).catch((error) => console.error("Page Annotator could not follow the page change", error));
  }

  function bind() {
    if (extensionAlive()) {
      try {
        chrome.runtime.onMessage.addListener((message) => {
          if (!extensionAlive()) {
            retire();
            return;
          }
          if (!message || message.type !== "tqa-ann-toggle") return;
          void toggleBar();
        });
        chrome.storage.onChanged.addListener((changes, area) => {
          if (!extensionAlive()) {
            retire();
            return;
          }
          if (area !== "local" || !changes[STORE_KEY] || writesInFlight > 0 || state.editor) return;
          const data = changes[STORE_KEY].newValue;
          if (!data) return;
          memory = {
            lastColor: data.lastColor === "purple" ? "purple" : "yellow",
            annotationsVisible: data.annotationsVisible !== false,
            summaryOpacity: clampOpacity(data.summaryOpacity),
            summaryFrame: normalizeFrame(data.summaryFrame),
            pages: data.pages && typeof data.pages === "object" ? data.pages : {}
          };
          const incoming = annotationsFromMemory(state.page);
          const same = JSON.stringify(incoming.map(serialize)) === JSON.stringify(state.annotations.map(serialize));
          state.lastColor = memory.lastColor;
          state.summaryOpacity = memory.summaryOpacity;
          state.summaryFrame = memory.summaryFrame;
          applyOpacity();
          applyFrame();
          if (same && state.annotationsVisible === memory.annotationsVisible) return;
          state.annotationsVisible = memory.annotationsVisible;
          state.annotations = incoming;
          syncMarks();
          renderVisibility();
        });
      } catch (error) {
        if (isContextError(error)) retire(error);
      }
    }
    document.addEventListener("mouseup", onMouseUp, true);
    document.addEventListener("mousedown", onMouseDown, true);
    window.addEventListener("mousemove", onSummaryGestureMove, true);
    window.addEventListener("mouseup", onSummaryGestureEnd, true);
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("mouseover", (event) => {
      if (!state.barOpen || !state.annotationsVisible || state.editor) return;
      const mark = closestMark(event.target);
      if (!mark) return;
      clearTimeout(hoverTimer);
      showHover(mark.dataset.annId);
    });
    document.addEventListener("mouseout", (event) => {
      const mark = closestMark(event.target);
      if (!mark) return;
      const next = closestMark(event.relatedTarget);
      if (next && next.dataset.annId === mark.dataset.annId) return;
      clearTimeout(hoverTimer);
      hoverTimer = window.setTimeout(hideHover, 80);
    });
    ui.hover.addEventListener("mouseenter", () => clearTimeout(hoverTimer));
    ui.hover.addEventListener("mouseleave", () => {
      clearTimeout(hoverTimer);
      hoverTimer = window.setTimeout(hideHover, 80);
    });
    window.addEventListener("scroll", () => {
      if (state.editor) placeEditor(state.editor.id);
      if (state.hoverId) placeHover();
    }, true);
    window.addEventListener("resize", () => {
      if (state.editor) placeEditor(state.editor.id);
      if (state.summaryFrame) state.summaryFrame = clampFrame(state.summaryFrame, "");
      applyFrame();
    });
  }

  async function init() {
    if (!extensionAlive()) {
      window.__tqaAnnBooted = false;
      return;
    }
    try {
      memory = await readStore();
      if (restoreFromSiteBackup()) {
        try {
          await chrome.storage.local.set({ [STORE_KEY]: memory });
        } catch (error) {
          if (isContextError(error)) {
            retire(error);
            return;
          }
          console.error("Annotator could not restore saved notes", error);
        }
      }
      writeSiteBackup();
      state.lastColor = memory.lastColor;
      state.annotationsVisible = memory.annotationsVisible;
      state.summaryOpacity = memory.summaryOpacity;
      state.summaryFrame = memory.summaryFrame;
      state.page = TqaAnchor.pageKeyFromHref(location.href);
      state.annotations = annotationsFromMemory(state.page);
      mount();
      bind();
      await loadNotetaker();
      await refreshAudioFlags();
      hookHistory();
      applyOpacity();
      applyFrame();
      renderVisibility();
      renderList();
      void injectMarkCss().catch((error) => {
        if (isContextError(error)) retire(error);
        else console.error("Annotator could not load highlight styles", error);
      });
    } catch (error) {
      if (isContextError(error)) retire(error);
      else console.error("Annotator failed to start", error);
    }
  }

  init().catch((error) => {
    if (isContextError(error)) retire(error);
    else console.error("Annotator failed to start", error);
  });
})();
