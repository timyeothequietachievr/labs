# Annotator (Beta)

A Chrome extension for highlighting text on any page, tagging feedback, adding comments, recording short audio notes, and sharing a read-receipt link.

This is a **beta**. It is not in the Chrome Web Store. You install it once with Developer mode.

## Install (Chrome)

1. Unzip this download. You should see a folder that contains `manifest.json`.
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked**.
5. Choose the unzipped folder (the one that contains `manifest.json`).
6. Pin **Annotator** from the puzzle-piece extensions menu.
7. Open any web page, refresh it, then click the Annotator toolbar icon.

Chrome may show a warning while Developer mode is on. Dismiss it. The extension keeps running.

## Use

- Click the toolbar icon to show or hide the bar.
- Select text and release the mouse to save a highlight.
- Add a colour, feedback tag, comment, or audio note in the editor.
- Open **Summary** to filter, jump to highlights, and play recordings.
- Sign in to create a **Share link** so someone else can open a snapshot of the annotated page.

Send feedback or suggestions from the bar link, or email [annotator@thequietachievr.com](mailto:annotator@thequietachievr.com?subject=Annotator%20feedback%20and%20suggestions).

## Notes

- Chrome only (not Safari or Firefox).
- Notes are stored in Chrome on your computer. Share links use Annotator’s share service.
- To update later: download a newer zip, replace the folder, then click the reload icon on the Annotator card at `chrome://extensions`, and refresh your tabs.
